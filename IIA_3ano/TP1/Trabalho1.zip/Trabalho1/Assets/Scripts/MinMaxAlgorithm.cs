﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DeepCopyExtensions;

public class MinMaxAlgorithm: MoveMaker
{
    public EvaluationFunction evaluator;
    private UtilityFunction utilityfunc; 
    public int depth =6;
    private PlayerController MaxPlayer;
    private PlayerController MinPlayer;
    private bool isAlphaBeta;
    private int time;

    public MinMaxAlgorithm(PlayerController MaxPlayer, EvaluationFunction eval, UtilityFunction utilf, PlayerController MinPlayer, bool ab)
    {
        this.MaxPlayer = MaxPlayer;
        this.MinPlayer = MinPlayer;
        this.evaluator = eval;
        this.utilityfunc = utilf;
        this.isAlphaBeta = ab;
    }

    public override State MakeMove()
    {
        // The move is decided by the selected state
        return GenerateNewState(); 
    }

    private State GenerateNewState()
    {
        // Creates initial state
        State newState = new State(this.MaxPlayer, this.MinPlayer);
        // Call the MinMax implementation
        State bestMove;
        if (this.isAlphaBeta)
        {
            bestMove = MinMaxAlphaBeta(true, newState, depth, float.MinValue, float.MaxValue);
        }
        else
        {
            bestMove = MinMax(true, newState, depth);
        }
        //Debug.Log(bestMove.Score);
        //boolean para dizer que sou o max
        //max expanded nodes para limitar o numero de niveis que quero visistar? depth já é variavel
        //enviar o board de cada decisao que tomamos o mimmax vai ser recursivo
        // returning the actual state. You should modify this
        this.time += this.MaxPlayer.ExpandedNodes;
        this.MaxPlayer.ExpandedNodes = 0;
        Debug.Log(this.time);
        return bestMove;
    }
    public State MinMaxAlphaBeta(Boolean myself, State board, int depth, float alpha, float beta)
    {
        //Debug.Log("depth:" + depth + "// x:" + board.PlayersUnits[0].x + " y: " + board.PlayersUnits[0].y + " score: " + board.Score + " atack?" + board.isAttack);

        if (board.AdversaryUnits.Count == 0 || board.PlayersUnits.Count == 0)
        {
            if (myself)
            {
                board = new State(board);
                board.Score = this.utilityfunc.evaluate(board, depth);
            }
            else
            {
                board.Score = this.utilityfunc.evaluate(board, depth);
                
            }
            //Debug.Log(board.Score + " "+board.PlayersUnits[0].id);
            return board;
        }


        //if(this.MaxPlayer.ExpandedNodes >= this.MaxPlayer.MaximumNodesToExpand)
        if (depth == 0  || this.MaxPlayer.ExpandedNodes >= this.MaxPlayer.MaximumNodesToExpand)
        {
            //game over ou limite de expanded nodes
            if (myself)
            {
                board = new State(board);
                board.Score = this.evaluator.evaluate(board);

            }
            else
            {
                board.Score = this.evaluator.evaluate(board);

            }
            //Debug.Log(board.Score );
            return board;
        }

        
        List<State> states;
        if (depth == this.depth)
        {
            //se estivermos a expandir por numero de nos, usar condiçao this.MaxPlayer.ExpandedNodes==0
            states = GeneratePossibleStates(board);
        }
        else
        {
            states = GeneratePossibleStates(new State(board));
        }

        if (myself) //maximizar
        {
            State currentMove;
            State bestMove = new State(board);
            bestMove.Score = float.MinValue;

            foreach (State node in states)
            {
                //Só entra neste else quando a depth é igual a 1, na primeira vez que se chama o MinMax()
                currentMove = MinMaxAlphaBeta(false, node, depth - 1,alpha,beta);
                foreach (Unit u in currentMove.PlayersUnits)
                
                if (currentMove.Score > bestMove.Score)
                {
                    bestMove = currentMove;
                }

                if(alpha < currentMove.Score)
                {
                    alpha = currentMove.Score;
                }

                if(beta <= alpha) { break; }
            }

            if (bestMove.parentState.isRoot)
            {
                return bestMove;
            }
            //só o maximizar é que apanha a root
            bestMove.parentState.Score = bestMove.Score;
            bestMove = bestMove.parentState;
            return bestMove;
        }

        else //minimizar
        {
            State currentMove;
            State bestMove = new State(board);
            bestMove.Score = float.MaxValue;
            foreach (State node in states)
            {

                //currentMove = MinMax(true, node, depth - 1,alpha, beta);
                currentMove = MinMaxAlphaBeta(true, node, depth - 1, alpha, beta);

                if (currentMove.Score < bestMove.Score)
                {
                    bestMove = currentMove;
                }

                if(beta > currentMove.Score)
                {
                    beta = currentMove.Score;
                }

                if(beta <= alpha) { break; }
            }
            bestMove.parentState.Score = bestMove.Score;
            bestMove = bestMove.parentState;

            return bestMove;
        }
    }



    public State MinMax(Boolean myself, State board, int depth)
    {
        // Debug.Log("depth:" + depth + "// x:" + board.PlayersUnits[0].x + " y: " + board.PlayersUnits[0].y + " score: " + board.Score + " atack?" + board.isAttack);

        if (board.AdversaryUnits.Count == 0 || board.PlayersUnits.Count == 0)
        {
            if (myself)
            {
                board = new State(board);
                board.Score = this.utilityfunc.evaluate(board, depth);
            }
            else
            {
                board.Score = this.utilityfunc.evaluate(board, depth);

            }
            //Debug.Log(board.Score + " "+board.PlayersUnits[0].id);
            return board;
        }


        //if(this.MaxPlayer.ExpandedNodes >= this.MaxPlayer.MaximumNodesToExpand)
        if (depth == 0 || this.MaxPlayer.ExpandedNodes >= this.MaxPlayer.MaximumNodesToExpand)
        {
            //game over ou limite de expanded nodes
            if (myself)
            {
                board = new State(board);
                board.Score = this.evaluator.evaluate(board);

            }
            else
            {
                board.Score = this.evaluator.evaluate(board);

            }
            //Debug.Log(board.Score );
            return board;
        }


        List<State> states;
        if (depth == this.depth)
        {
            //se estivermos a expandir por numero de nos, usar condiçao this.MaxPlayer.ExpandedNodes==0
            states = GeneratePossibleStates(board);
        }
        else
        {
            states = GeneratePossibleStates(new State(board));
        }

        if (myself) //maximizar
        {
            State currentMove;
            State bestMove = new State(board);
            bestMove.Score = float.MinValue;

            foreach (State node in states)
            {
                //Só entra neste else quando a depth é igual a 1, na primeira vez que se chama o MinMax()
                currentMove = MinMax(false, node, depth - 1);
                foreach (Unit u in currentMove.PlayersUnits)

                    if (currentMove.Score > bestMove.Score)
                    {
                        bestMove = currentMove;
                    }

            }

            if (bestMove.parentState.isRoot)
            {
                return bestMove;
            }
            //só o maximizar é que apanha a root
            bestMove.parentState.Score = bestMove.Score;
            bestMove = bestMove.parentState;
            return bestMove;
        }

        else //minimizar
        {
            State currentMove;
            State bestMove = new State(board);
            bestMove.Score = float.MaxValue;
            foreach (State node in states)
            {

                //currentMove = MinMax(true, node, depth - 1,alpha, beta);
                currentMove = MinMax(true, node, depth - 1);

                if (currentMove.Score < bestMove.Score)
                {
                    bestMove = currentMove;
                }
                
            }
            bestMove.parentState.Score = bestMove.Score;
            bestMove = bestMove.parentState;

            return bestMove;
        }
    }

    private List<State> GeneratePossibleStates(State state)
    {
        List<State> states = new List<State>();
        //Generate the possible states available to expand
        foreach(Unit currentUnit in state.PlayersUnits)
        {
            // Movement States
            List<Tile> neighbours = currentUnit.GetFreeNeighbours(state);
            foreach (Tile t in neighbours)
            {
                State newState = new State(state, currentUnit, true);
                newState = MoveUnit(newState, t);
                states.Add(newState);
            }
            // Attack states
            List<Unit> attackOptions = currentUnit.GetAttackable(state, state.AdversaryUnits);
            foreach (Unit t in attackOptions)
            {
                State newState = new State(state, currentUnit, false);
                newState = AttackUnit(newState, t);
                states.Add(newState);
            }

        }

        // YOU SHOULD NOT REMOVE THIS
        // Counts the number of expanded nodes;
        this.MaxPlayer.ExpandedNodes += states.Count;
        //

        return states;
    }

    private State MoveUnit(State state,  Tile destination)
    {
        Unit currentUnit = state.unitToPermormAction;
        //First: Update Board
        state.board[(int)destination.gridPosition.x, (int)destination.gridPosition.y] = currentUnit;
        state.board[currentUnit.x, currentUnit.y] = null;
        //Second: Update Players Unit Position
        currentUnit.x = (int)destination.gridPosition.x;
        currentUnit.y = (int)destination.gridPosition.y;
        state.isMove = true;
        state.isAttack = false;
        return state;
    }

    private State AttackUnit(State state, Unit toAttack)
    {
        Unit currentUnit = state.unitToPermormAction;
        Unit attacked = toAttack.DeepCopyByExpressionTree();

        Tuple<float, float> currentUnitBonus = currentUnit.GetBonus(state.board, state.PlayersUnits);
        Tuple<float, float> attackedUnitBonus = attacked.GetBonus(state.board, state.AdversaryUnits);


        attacked.hp += Math.Min(0, (attackedUnitBonus.Item1)) - (currentUnitBonus.Item2 + currentUnit.attack);
        state.unitAttacked = attacked;

        state.board[attacked.x, attacked.y] = attacked;
        int index = state.AdversaryUnits.IndexOf(attacked);
        state.AdversaryUnits[index] = attacked;



        if (attacked.hp <= 0)
        {
            //Board update by killing the unit!
            state.board[attacked.x, attacked.y] = null;
            index = state.AdversaryUnits.IndexOf(attacked);
            state.AdversaryUnits.RemoveAt(index);

        }
        state.isMove = false;
        state.isAttack = true;

        return state;

    }
}
