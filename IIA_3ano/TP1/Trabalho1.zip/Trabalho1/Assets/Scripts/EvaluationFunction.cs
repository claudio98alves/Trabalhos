﻿using UnityEngine;
using System.Collections;
using System;
abstract
public class EvaluationFunction
{
    // Do the logic to evaluate the state of the game !
    abstract
    public float evaluate(State s);

   
    //conta o numero de ataques plauer
    public float countAtacks(State s)
    {
        if (s.isRoot)
        {
            return 0;
        }
        if (s.isAttack)
        {
            return s.unitToPermormAction.attack + countAtacks(s.parentState);
        }
        else
        {
            if (s.parentState.isRoot)
            {
                return countAtacks(s.parentState);
            }
            return countAtacks(s.parentState.parentState);
        }
    }
    


}

