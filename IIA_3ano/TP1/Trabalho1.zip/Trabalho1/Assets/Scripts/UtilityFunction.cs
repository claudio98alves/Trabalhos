﻿using UnityEngine;
using System.Collections;
using System;

public class UtilityFunction
{
    //state é true quando é o inimigo
    public float evaluate(State s,int depth)
    {
        if (s.AdversaryUnits.Count==0 )
        {
            return 999999 + depth;
        }

        else
        {
            return -999999 - depth;
        }
       

    }
}
