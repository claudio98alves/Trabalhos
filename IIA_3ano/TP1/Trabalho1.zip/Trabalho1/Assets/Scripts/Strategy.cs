﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Strategy : EvaluationFunction
{
    override
     public float evaluate(State s)
    {

        float score = 0;

        score += 1000 * (s.PlayersUnits.Count - s.AdversaryUnits.Count);
        

        foreach (Unit u in s.PlayersUnits)
        {

            Protector prot = u as Protector;
            if (prot != null)
            {
                score -= prot.maxHp - prot.hp;
                score += 10 * countBonus(s, prot);
            }
            Warrior war = u as Warrior;
            if (war != null)
            {
                score -= war.maxHp - war.hp;
                score += 10 * countBonus(s, war);
            }
            Mage mage = u as Mage;
            if (mage != null)
            {
                score += 5 * mage.GetFreeNeighbours().Count;
                score += 25;
                score -= 3 * (mage.maxHp - mage.hp);
                score += 30 * countBonus(s, mage);
            }
            Assassin ass = u as Assassin;
            if (ass != null)
            {
                score += 10 * ass.GetFreeNeighbours().Count;
                score += 50;
                score -= 4 * (ass.maxHp - ass.hp);
                score += 30 * countBonus(s, ass);
            }
        }


        foreach (Unit u in s.AdversaryUnits)
        {

            Protector prot = u as Protector;
            if (prot != null)
            {
                score += prot.maxHp - prot.hp;

            }
            Warrior war = u as Warrior;
            if (war != null)
            {
                score += war.maxHp - war.hp;

            }
            Mage mage = u as Mage;
            if (mage != null)
            {
                score -= 25;
                score += 2 * (mage.maxHp - mage.hp);

            }
            Assassin ass = u as Assassin;
            if (ass != null)
            {

                score -= 50;
                score += 3 * (ass.maxHp - ass.hp);

            }
        }


        return score;
    }

    //conta o numero de bonus que o player tem no momento
    public int countBonus(State s, Unit u)
    {
        int[,] bonusneighbourhood = {
            {0, 1}, {1, 0}, {0, -1}, {-1, 0}, //{0,0},
            {1,1},  {-1,1}, {1,-1}, {-1,-1},
        };
        int gridSizeX = s.board.GetLength(0);
        int gridSizeY = s.board.GetLength(1);
        int countBonus = 0;

        for (int i = 0; i < bonusneighbourhood.GetLength(0); i++)
        {
            int checkX = u.x + bonusneighbourhood[i, 0];
            int checkY = u.y + bonusneighbourhood[i, 1];
            if (checkX >= 0 && checkX < gridSizeX && checkY >= 0 && checkY < gridSizeY)
            {
                Unit neighbour = s.board[checkX, checkY];

                if (neighbour != null && !neighbour.IsDead() && s.PlayersUnits.Contains(neighbour))
                {
                    Protector prot = neighbour as Protector;
                    if (prot != null)
                    {//hp bonus
                        countBonus += 1;
                    }
                    Warrior warr = neighbour as Warrior;
                    if (warr != null)
                    {//attack bonus
                        countBonus += 2;
                    }
                }
            }
        }
        return countBonus * 10;
    }
}