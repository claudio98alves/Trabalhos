﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunOnly:EvaluationFunction
{
    override
    public float evaluate(State s)
    {

        float score = 0;

        score -= 1000 * (s.AdversaryUnits.Count - s.PlayersUnits.Count);
        //Debug.Log("run");
        foreach (Unit u in s.PlayersUnits)
        {

            Protector prot = u as Protector;
            if (prot != null)
            {
                score -= prot.maxHp - prot.hp;
            }
            Warrior war = u as Warrior;
            if (war != null)
            {
                score -= war.maxHp - war.hp;
            }
            Mage mage = u as Mage;
            if (mage != null)
            {
                score -= 2 * (mage.maxHp - mage.hp);
            }
            Assassin ass = u as Assassin;
            if (ass != null)
            {
                score -= 2 * (ass.maxHp - ass.hp);
            }
        }
        return score;
    }
}
