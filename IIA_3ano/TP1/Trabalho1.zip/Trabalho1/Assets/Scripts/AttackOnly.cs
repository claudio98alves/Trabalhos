﻿using UnityEngine;
using System.Collections;
using System;

public class AttackOnly:EvaluationFunction
{
    override
    public float evaluate(State s)
    {

        float score = 0;
        //Debug.Log("attack");
        score += 1000 * (s.PlayersUnits.Count - s.AdversaryUnits.Count);
        foreach (Unit u in s.AdversaryUnits)
        {

            Protector prot = u as Protector;
            if (prot != null)
            {
                score += prot.maxHp - prot.hp;

            }
            Warrior war = u as Warrior;
            if (war != null)
            {
                score += war.maxHp - war.hp;

            }
            Mage mage = u as Mage;
            if (mage != null)
            {
                score += 2 * (mage.maxHp - mage.hp);

            }
            Assassin ass = u as Assassin;
            if (ass != null)
            {
                score += 2 * (ass.maxHp - ass.hp);

            }
        }
        return score;
    }
  

    //conta o numero de bonus que o player tem no momento
 
}

