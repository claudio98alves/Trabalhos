﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveMaker
{
    public virtual State MakeMove()
    {
        return null;
    }

}