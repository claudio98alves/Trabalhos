﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DeepCopyExtensions;

public class MinMaxAlgorithm: MoveMaker
{
    public EvaluationFunction evaluator;
    private UtilityFunction utilityfunc; 
    public int depth = 20;
    private PlayerController MaxPlayer;
    private PlayerController MinPlayer;
    
    public MinMaxAlgorithm(PlayerController MaxPlayer, EvaluationFunction eval, UtilityFunction utilf, PlayerController MinPlayer)
    {
        this.MaxPlayer = MaxPlayer;
        this.MinPlayer = MinPlayer;
        this.evaluator = eval;
        this.utilityfunc = utilf;
    }

    public override State MakeMove()
    {
        // The move is decided by the selected state
        return GenerateNewState(); 
    }
    //MEXER AQUI!!!!!!!!!!!!
    private State GenerateNewState()
    {
        // Creates initial state
        State newState = new State(this.MaxPlayer, this.MinPlayer); 
        // Call the MinMax implementation
        State bestMove= MinMax(true, newState,depth);
        //Debug.Log(bestMove.Score);
        //boolean para dizer que sou o max
        //max expanded nodes para limitar o numero de niveis que quero visistar? depth já é variavel
        //enviar o board de cada decisao que tomamos o mimmax vai ser recursivo
        // returning the actual state. You should modify this
        return bestMove;
    }
    //MEXER AQUI!!!!!!!!!!!!
    //max é o player que está a jogar
    //os states da lista têm a depth atualizada consoante a tree
    public State MinMax(Boolean myself,State board,int depth)
    {
        if (utilityfunc.evaluate(board) == 0 || depth==0)
        {
            //game over ou limite de expanded nodes
            board.Score = this.evaluator.evaluate(board);
            return board;
        }

        List<State> states = GeneratePossibleStates(board);
        if (myself) //maximizar
        {
            State currentMove;
            State bestMove = new State(board);
            bestMove.Score = int.MinValue;

            foreach(State nodeMin in states)
            {
                if (this.depth != depth)
                {
                    State node = new State(nodeMin);
                    currentMove = MinMax(!myself, node, depth - 1);
                }
                else
                {
                    //Só entra neste else quando a depth é igual a 1, na primeira vez que se chama o MinMax()
                    currentMove = MinMax(!myself, nodeMin, depth - 1);
                }

                if (currentMove.Score > bestMove.Score)
                {
                    bestMove = currentMove;
                }
            }
            if (bestMove.parentState.isRoot)
            {
                return bestMove;
            }
            //só o maximizar é que apanha a root
            bestMove.parentState.Score = bestMove.Score;
            bestMove = bestMove.parentState;
            return bestMove;
        }
        else //minimizar
        {
            
            State currentMove;
            State bestMove = new State(board);
            bestMove.Score = int.MaxValue;
            foreach (State nodeMax in states)
            {
                //min max perspective, ou seja, trocar os adv com myUnits para gerar as possibilidades do adv
                State node = new State(nodeMax);
                currentMove = MinMax(!myself, node,depth-1);
                if (currentMove.Score < bestMove.Score)
                {
                    bestMove = currentMove;
                }
            }
            bestMove.parentState.Score = bestMove.Score;
            bestMove = bestMove.parentState;
            return bestMove;
        }
    }
    //Não mexer para baixo

    //nao preciso de mexer gera todos os movimentos possiveis
    private List<State> GeneratePossibleStates(State state)
    {
        List<State> states = new List<State>();
        //Generate the possible states available to expand
        foreach(Unit currentUnit in state.PlayersUnits)
        {
            // Movement States
            List<Tile> neighbours = currentUnit.GetFreeNeighbours(state);
            foreach (Tile t in neighbours)
            {
                State newState = new State(state, currentUnit, true);
                newState = MoveUnit(newState, t);
                states.Add(newState);
            }
            // Attack states
            List<Unit> attackOptions = currentUnit.GetAttackable(state, state.AdversaryUnits);
            foreach (Unit t in attackOptions)
            {
                State newState = new State(state, currentUnit, false);
                newState = AttackUnit(newState, t);
                states.Add(newState);
            }

        }

        // YOU SHOULD NOT REMOVE THIS
        // Counts the number of expanded nodes;
        this.MaxPlayer.ExpandedNodes += states.Count;
        //

        return states;
    }
    //fim de Func

    private State MoveUnit(State state,  Tile destination)
    {
        Unit currentUnit = state.unitToPermormAction;
        //First: Update Board
        state.board[(int)destination.gridPosition.x, (int)destination.gridPosition.y] = currentUnit;
        state.board[currentUnit.x, currentUnit.y] = null;
        //Second: Update Players Unit Position
        currentUnit.x = (int)destination.gridPosition.x;
        currentUnit.y = (int)destination.gridPosition.y;
        state.isMove = true;
        state.isAttack = false;
        return state;
    }

    private State AttackUnit(State state, Unit toAttack)
    {
        Unit currentUnit = state.unitToPermormAction;
        Unit attacked = toAttack.DeepCopyByExpressionTree();

        Tuple<float, float> currentUnitBonus = currentUnit.GetBonus(state.board, state.PlayersUnits);
        Tuple<float, float> attackedUnitBonus = attacked.GetBonus(state.board, state.AdversaryUnits);


        attacked.hp += Math.Min(0, (attackedUnitBonus.Item1)) - (currentUnitBonus.Item2 + currentUnit.attack);
        state.unitAttacked = attacked;

        if (attacked.hp <= 0)
        {
            //Board update by killing the unit!
            state.board[attacked.x, attacked.y] = null;
            int index = state.AdversaryUnits.IndexOf(attacked);
            state.AdversaryUnits.RemoveAt(index);

        }
        state.isMove = false;
        state.isAttack = true;

        return state;

    }
}
