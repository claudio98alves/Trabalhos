﻿using UnityEngine;
using System.Collections;
using System;

public class EvaluationFunction
{
    // Do the logic to evaluate the state of the game !
    public float evaluate(State s)
    {
        //strategy tentar prever a proxima jogada do adversário
        //dar pior pontuação para quando vou jogar para uma posição na qual posso ser atacado

        float Score = 0;

        

        return Score;
    }
}
