﻿using UnityEngine;
using System.Collections;
using System;

public class UtilityFunction
{

    public float evaluate(State s)
    {
        if (s.AdversaryUnits.Count == 0 || s.PlayersUnits.Count == 0)
        {
            return 0;
        }

        return 1;
        
    }
}
