#include "structures.h"
#include "semantics.h"
#include "symbol_table.h"
#include<stdlib.h>
#include<string.h>
#include <stdio.h>


int checkStatement(is_statement* aux,is_funcdec* fd);
int checkFuncinvoc(is_funcinvoc* fi, is_funcdec* fd);
/*extern symbtab!!!!!!!!*/
int check_program(is_program* p) {
	int error=0;
	is_declaration_list* tmp;
	for(tmp=p->dlist; tmp; tmp=tmp->next){
	    error+=check_vardec(tmp->v);
	    //printf("%s\n",tmp->fd->id);
	    error+=check_funcdecSt(tmp->fd);
	}
	for(tmp=p->dlist; tmp; tmp=tmp->next){
		if(tmp->fd!=NULL){
		   if(check_search_func(tmp->fd)==tmp->fd->linha){
				error+=check_funcdec(tmp->fd);
			}
		}
	}
	error += checkVars();
	return error;
}

int check_vardec(is_vardec* var){
    if(var!=NULL){
        return insert_var(var);       
    }
    return 0;
}

int checkBaseNot(is_expression* exp){
	if(exp->base!=NULL){
		list_base* tmp;
		for(tmp=exp->base; tmp; tmp=tmp->next){
			if(strcmp(tmp->strBase,"Not")==0)return 1;
		}
	}
	return 0;
}

int checkBaseOnlyNot(is_expression* exp){
	if(exp->base!=NULL){
		list_base* tmp;
		for(tmp=exp->base; tmp; tmp=tmp->next){
			if(strcmp(tmp->strBase,"Not")!=0)return 1;
		}
	}
	return 0;
}

char* printOperador(char *op){
	if(strcmp(op,"Add")==0){return "+";}
	if(strcmp(op,"Sub")==0){return "-";}
	if(strcmp(op,"Div")==0){return "/";}
	if(strcmp(op,"Mul")==0){return "*";}
	if(strcmp(op,"Eq")==0){return "==";}
	if(strcmp(op,"And")==0){return "&&";}
	
	if(strcmp(op,"Or")==0){return "||";}
	if(strcmp(op,"Mod")==0){return "%";}
	if(strcmp(op,"Ne")==0){return "!=";}

	if(strcmp(op,"Lt")==0){return "<";}
	if(strcmp(op,"Gt")==0){return ">";}
	
	if(strcmp(op,"Le")==0){return "<=";}
	if(strcmp(op,"Ge")==0){return ">=";}
	return op;
}

int check_Octal(char* str){
	if(strlen(str)>1 && str[0] == '0' && str[1] != 'x'){
		int i;
		for(i=1;i<strlen(str);i++){
			if(str[i] == '8' || str[i] == '9'){
				return 1;
			}
		}	
	}
	return 0;
	
}


int checkOperador(is_expression* expr){
	if(expr->operador!=NULL){
		if(strcmp(expr->operador,"Lt")==0 || strcmp(expr->operador,"Gt")==0 || strcmp(expr->operador,"Le")==0 || strcmp(expr->operador,"Ge")==0 ||strcmp(expr->operador,"Eq")==0 || strcmp(expr->operador,"Ne")==0 || strcmp(expr->operador,"Or")==0 || strcmp(expr->operador,"And")==0 ){
		return 1;
		}
	}
	if(expr->base!=NULL){
		list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0){
					return 1;
				}
			}
	}
	return 0;
}


char* checkExpressionType(is_expression* expr, is_funcdec* fd){
	if(expr->intlit!=NULL){
		if(expr->base!=NULL){
			list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0){
					printf("Line %d, column %d: Operator ! cannot be applied to type int\n",aux->linha,aux->coluna);
					return "bool";
				}
			}		
		}		
		if(check_Octal(expr->intlit)==1){
			printf("Line %d, column %d: Invalid octal constant: %s\n",expr->linha,expr->coluna,expr->intlit);
		}
		return "int";
	}
	if(expr->reallit!=NULL){
		if(expr->base!=NULL){
			list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0){
					printf("Line %d, column %d: Operator ! cannot be applied to type float32\n",aux->linha,aux->coluna);
					return "bool";
				}
			}		
		}
		return "float32";	
	}
	if(expr->id!=NULL){
		
		markId(expr->id,fd,expr->linha);
		if(search_var(expr->id,fd->id)==0){
			printf("Line %d, column %d: Cannot find symbol %s\n",expr->linha,expr->coluna,expr->id);
			return "undef";		
		}
		char* type = getVarType(expr->id,fd,expr->linha);
		if(expr->base!=NULL){
			list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0 && (strcmp(type,"Int")==0 || strcmp(type,"Float32")==0)){
					printf("Line %d, column %d: Operator ! cannot be applied to type %s\n",aux->linha,aux->coluna,toLow(type));
					return "bool";
				}
				if((strcmp(aux->strBase,"Plus")==0) &&  (strcmp(type,"Bool")==0 || strcmp(type,"String")==0) ){
					printf("Line %d, column %d: Operator + cannot be applied to type %s\n",aux->linha,aux->coluna,toLow(type));
					return "undef";
				}
				if(strcmp(aux->strBase,"Minus")==0 && (strcmp(type,"Bool")==0 || strcmp(type,"String")==0)){
					printf("Line %d, column %d: Operator - cannot be applied to type %s\n",aux->linha,aux->coluna,toLow(type));
					return "undef";
				}				
			}		
		}	
		
		//markId(expr->id,fd,expr->linha);
		return toLow(type);	
	}
	if(expr->funcinvoc!=NULL){
		//checkar paramentros da func
		if(checkFuncinvoc(expr->funcinvoc,fd)==0){
			return toLow(getFuncType(expr->funcinvoc->id));	
		}
		return "undef";
	}
	if(expr->operador!=NULL){
		char* right = checkExpressionType(expr->right,fd); 
		char* left = checkExpressionType(expr->left,fd); 
		if(strcmp(right,left)==0){
			//verificar o tipo de operaçoes que o operador pode reazliar
			if(strcmp(expr->operador,"Or")==0 || strcmp(expr->operador,"And")==0){
				//so aceitam bool
				if(strcmp(right,"bool")==0){return "bool";}
				else{
					printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);
					return "bool";
				}
			}
			if(strcmp(expr->operador,"Lt")==0 || strcmp(expr->operador,"Gt")==0 || strcmp(expr->operador,"Le")==0 || strcmp(expr->operador,"Ge")==0){
				//LT GT EQ NE LE GE both int or float32
				if(strcmp(right,"string")==0 || strcmp(right,"int")==0 || strcmp(right,"float32")==0){return "bool";}
				else{
					printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);	
					return "bool";			
				}
			}
			if( strcmp(expr->operador,"Eq")==0 || strcmp(expr->operador,"Ne")==0 ){
				if( strcmp(right,"string")==0 ||strcmp(right,"int")==0 || strcmp(right,"float32")==0 || strcmp(right,"bool")==0){return "bool";}
				else{
					printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);
					return "bool";	
				}	

			}
			if(strcmp(expr->operador,"Mod")==0){
				if(strcmp(right,"int")==0){return "int";}
				else{
					printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);
					return "undef";
				}
			}
			if(strcmp(expr->operador,"Div")==0 || strcmp(expr->operador,"Mul")==0 || strcmp(expr->operador,"Sub")==0 ){
				//DIV STAR MINUS
				if(strcmp(right,"int")==0){return "int";}
				if(strcmp(right,"float32")==0){return "float32";}
				else{
					printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);
					return "undef";
				}
			}
			if(strcmp(expr->operador,"Add")==0){
				//ADD
				if(strcmp(right,"int")==0){return "int";}
				if(strcmp(right,"float32")==0){return "float32";}
				if(strcmp(right,"string")==0){return "string";}
				else{
					printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);
					return "undef";
				}

			}
			else{
				printf("Invalid Operator\n");
				return "undef";	
			}
		}
		else{
			printf("Line %d, column %d: Operator %s cannot be applied to types %s, %s\n",expr->linha,expr->coluna,printOperador(expr->operador),left,right);
			if(checkOperador(expr)==1)return "bool";		
			return "undef";
		}
	}
	else{	printf("Expr sem nada\n"); return "undef";}
	

}


char* checkExpressionTypeSemP(is_expression* expr, is_funcdec* fd){
	if(expr->intlit!=NULL){
		if(expr->base!=NULL){
			list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0){
					return "bool";
				}
			}		
		}		
		return "int";
	}
	if(expr->reallit!=NULL){
		if(expr->base!=NULL){
			list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0){
					return "bool";
				}
			}		
		}
		return "float32";	
	}
	if(expr->id!=NULL){
		markId(expr->id,fd,expr->linha);
		if(search_var(expr->id,fd->id)==0){
			return "undef";		
		}
		char* type = getVarType(expr->id,fd,expr->linha);
		if(expr->base!=NULL){
			list_base* aux;
			for(aux=expr->base; aux; aux=aux->next){
				if(strcmp(aux->strBase,"Not")==0 && (strcmp(type,"Int")==0 || strcmp(type,"Float32")==0)){
					return "bool";
				}
				if((strcmp(aux->strBase,"Plus")==0) &&  (strcmp(type,"Bool")==0 || strcmp(type,"String")==0) ){
					return "undef";
				}
				if(strcmp(aux->strBase,"Minus")==0 && (strcmp(type,"Bool")==0 || strcmp(type,"String")==0)){
					return "undef";
				}				
			}		
		}	
		
		//markId(expr->id,fd,expr->linha);
		return toLow(type);	
	}
	if(expr->funcinvoc!=NULL){
		//checkar paramentros da func
		
		char* aux = toLow(getFuncType(expr->funcinvoc->id));	
		if(strcmp(aux,"null")==0){
			return "undef";
		}
		return aux;
	}
	if(expr->operador!=NULL){
		char* right = checkExpressionTypeSemP(expr->right,fd); 
		char* left = checkExpressionTypeSemP(expr->left,fd); 
		if(strcmp(right,left)==0){
			//verificar o tipo de operaçoes que o operador pode reazliar
			if(strcmp(expr->operador,"Or")==0 || strcmp(expr->operador,"And")==0){
				//so aceitam bool
				if(strcmp(right,"bool")==0){return "bool";}
				else{
					return "bool";
				}
			}
			if(strcmp(expr->operador,"Lt")==0 || strcmp(expr->operador,"Gt")==0 || strcmp(expr->operador,"Le")==0 || strcmp(expr->operador,"Ge")==0){
				//LT GT EQ NE LE GE both int or float32
				if(strcmp(right,"string")==0 || strcmp(right,"int")==0 || strcmp(right,"float32")==0){return "bool";}
				else{
					return "bool";			
				}
			}
			if( strcmp(expr->operador,"Eq")==0 || strcmp(expr->operador,"Ne")==0 ){
				if( strcmp(right,"string")==0 ||strcmp(right,"int")==0 || strcmp(right,"float32")==0 || strcmp(right,"bool")==0){return "bool";}
				else{
					return "bool";	
				}	

			}
			if(strcmp(expr->operador,"Mod")==0){
				if(strcmp(right,"int")==0){return "int";}
				else{
					return "undef";
				}
			}
			if(strcmp(expr->operador,"Div")==0 || strcmp(expr->operador,"Mul")==0 || strcmp(expr->operador,"Sub")==0 ){
				//DIV STAR MINUS
				if(strcmp(right,"int")==0){return "int";}
				if(strcmp(right,"float32")==0){return "float32";}
				else{
					return "undef";
				}
			}
			if(strcmp(expr->operador,"Add")==0){
				//ADD
				if(strcmp(right,"int")==0){return "int";}
				if(strcmp(right,"float32")==0){return "float32";}
				if(strcmp(right,"string")==0){return "string";}
				else{
					
					return "undef";
				}

			}
			else{
				printf("Invalid Operator\n");
				return "undef";	
			}
		}
		else{
			if(checkOperador(expr)==1)return "bool";		
			return "undef";
		}
	}
	else{	printf("Expr sem nada\n"); return "undef";}
	

}


int checkPrint(is_statement* aux,is_funcdec* fd){
	if(aux->print->strlit!=NULL){
		return 0;
	}
	if(aux->print->expr!=NULL){
		char* type = checkExpressionType(aux->print->expr,fd);
		if(strcmp(type,"undef")==0){return 1;}
		return 0;	
	}	
	printf("Print Error\n");
	return 1;
}

int check_assign(is_statement* sta,is_funcdec* fd){
	//type do id para o assign
	//printf("%s\n",sta->assign->id);
	char* type=toLow(getVarType(sta->assign->id,fd,sta->assign->linha));	

	if(strcmp(type,"null")==0){
        	printf("Line %d, column %d: Cannot find symbol %s\n",sta->assign->linhaI,sta->assign->colunaI,sta->assign->id);
        	type="undef";
	}
	markId(sta->assign->id,fd,sta->assign->linha);
	char* exprType = checkExpressionType(sta->assign->expr,fd);
	if(strcmp(type,exprType)==0 && strcmp(type,"undef")!=0){
		//assiogn valido
		return 0;
	}
	if(strcmp(exprType,"null")==0){
		printf("Line %d, column %d: Operator = cannot be applied to types %s, none\n",sta->assign->linha,sta->assign->coluna,type);
	}
	else printf("Line %d, column %d: Operator = cannot be applied to types %s, %s\n",sta->assign->linha,sta->assign->coluna,type,exprType);
	return 1;
}


int checkParams(is_params* p){
	is_params* paux;
	if(p==NULL){return 0;}
	int error=0;
	for(paux=p;paux->next;paux=paux->next){
		is_params* tmp;		
		for(tmp=paux->next;tmp;tmp=tmp->next){
			if(strcmp(paux->id,tmp->id)==0){
				printf("Line %d, column %d: Symbol %s already defined\n",tmp->linha,tmp->coluna,tmp->id);
				error++;
			}
		}

	}
	return error;


}


int check_funcdecSt(is_funcdec* fd){
    int error=0;    
    if(fd!=NULL){
           table_element* symbol = insert_func(fd);
	   error+=checkParams(fd->params);
 	   if(symbol==NULL)return 1;
	   /*percorrer varandstatements e ver tudo*/
	   is_varstatements* aux;
	   for(aux=fd->list_vs; aux; aux=aux->next){
		if(aux->vardec!=NULL){
			error+=insert_varInFunc(symbol,aux->vardec);
		}
	   }
    }
    return error;
}
is_expression* printfForIf(is_expression* expr){
	is_expression* aux;
	for(aux=expr; aux->operador!=NULL;aux=aux->left){
	};
	return aux;
}
int checkReturn(is_return* ret, is_funcdec* fd){
	if(fd->type!=NULL){
		if(ret->expr==NULL){
			printf("Line %d, column %d: Incompatible type none in return statement\n",ret->linha,ret->coluna-6);
			return 1;		
		}
		char *type = checkExpressionType(ret->expr,fd);
		if(strcmp(type,toLow(fd->type))==0){
			return 0;
		}
		printf("Line %d, column %d: Incompatible type %s in return statement\n",ret->linha,ret->coluna,type);
		return 1;
	}
	else{//func nao tem return;
		if(ret->expr!=NULL){
			printf("Line %d, column %d: Incompatible type %s in return statement\n",ret->expr->linha,ret->expr->coluna,checkExpressionType(ret->expr,fd));
			return 1;
		}
	}
	return 0;
}


int checkFor(is_for* fb,is_funcdec* fd){
	if(fb->expr==NULL){
		//verificar os statements dentro do for
			list_statements* aux;
			int errorAux=0;
			for(aux=fb->list_s;aux;aux=aux->next){
				errorAux+=checkStatement(aux->state,fd);
			}	
			return errorAux;
	}
	char *auxType = checkExpressionType(fb->expr,fd);
	checkOperador(fb->expr);
	if(strcmp("bool",auxType)==0 || checkOperador(fb->expr)==1){
			//verificar os statements dentro do for
			list_statements* aux;
			int errorAux=0;
			for(aux=fb->list_s;aux;aux=aux->next){
				errorAux+=checkStatement(aux->state,fd);
			}	
			return errorAux;
	}
	else{
		is_expression* tmp = printfForIf(fb->expr);
		printf("Line %d, column %d: Incompatible type %s in for statement\n",tmp->linha,tmp->coluna,auxType);
		list_statements* aux;
		int errorAux=0;
		for(aux=fb->list_s;aux;aux=aux->next){
			errorAux+=checkStatement(aux->state,fd);
		}	
		return errorAux+1;
	}

}


int checkIf(is_if* ifb, is_funcdec* fd){
	if(strcmp("bool",checkExpressionType(ifb->expr,fd))==0){
		list_statements* aux;
		int errorAux=0;		
		for(aux=ifb->list_state;aux;aux=aux->next){
			errorAux +=checkStatement(aux->state,fd);
		}
		if(ifb->list_els!=NULL){
			for(aux=ifb->list_state;aux;aux=aux->next){
				errorAux +=checkStatement(aux->state,fd);
			}
		}
		return errorAux;	
	}
	else{
		
		is_expression* tmp = printfForIf(ifb->expr);
		printf("Line %d, column %d: Incompatible type %s in if statement\n",tmp->linha,tmp->coluna,checkExpressionType(ifb->expr,fd));
		list_statements* aux;
		int errorAux=0;	
		for(aux=ifb->list_state;aux;aux=aux->next){
			errorAux +=checkStatement(aux->state,fd);
		}
		if(ifb->list_els!=NULL){
			for(aux=ifb->list_state;aux;aux=aux->next){
				errorAux +=checkStatement(aux->state,fd);
			}
		}
		return errorAux+1;
	}


}

int checkFuncinvoc(is_funcinvoc* fi, is_funcdec* fd){
	is_params* p = getFuncParams(fi->id);
	
	if(p==NULL && fi->list_expr==NULL){
		if(check_ffinvoc(fi->id)==0){//funcao nao existe
			printf("Line %d, column %d: Cannot find symbol %s()\n",fi->linha,fi->coluna,fi->id);
			return 1;
		}
		return 0;
	} //void func
	if(p!=NULL && fi->list_expr!=NULL){
		//compare p->type com checkExpression(fi->list_expr->expr)
		list_expression* aux = fi->list_expr;
		int error=0;
		while(p!=NULL && aux!=NULL){
			char * tmp = checkExpressionType(aux->expr,fd);
			if(strcmp(toLow(p->type),tmp)!=0){
				if(error==0){
					printf("Line %d, column %d: Cannot find symbol %s(",fi->linha,fi->coluna,fi->id);
					list_expression* tmp2;
					for(tmp2=fi->list_expr;tmp2;tmp2=tmp2->next){
						if(tmp2->next==NULL){
							printf("%s",checkExpressionTypeSemP(tmp2->expr,fd));
						}else{
							printf("%s,",checkExpressionTypeSemP(tmp2->expr,fd));
						}
					}		
					printf(")\n");
				}				
				error++;
			}
			p=p->next;
			aux=aux->next;
		}
		return error;
	}
	else{
		printf("Line %d, column %d: Cannot find symbol %s(",fi->linha,fi->coluna,fi->id);
		list_expression* tmp;
		for(tmp=fi->list_expr;tmp;tmp=tmp->next){
			if(tmp->next==NULL){
				printf("%s",checkExpressionTypeSemP(tmp->expr,fd));
			}else{
				printf("%s,",checkExpressionTypeSemP(tmp->expr,fd));
			}
		}		
		printf(")\n");

		if(fi->list_expr!=NULL){
			list_expression* aux;
			for(aux=fi->list_expr;aux;aux=aux->next){
				checkExpressionType(aux->expr,fd);
			}
		}
		return 1;
	}
}

int checkStatement(is_statement* aux,is_funcdec* fd){

	if(aux->print!=NULL){
		return checkPrint(aux,fd);
	}
	if(aux->funcinvoc!=NULL){
		//qualquer que seja o return...
		
		return checkFuncinvoc(aux->funcinvoc,fd);
	}	
	if(aux->args!=NULL){
		char * idType = toLow(getVarType(aux->args->id,fd,aux->args->linha));
		markId(aux->args->id,fd,aux->args->linha);
		char * expType =checkExpressionType(aux->args->expr,fd);
		if(strcmp(idType,"int")==0 && strcmp(expType,"int")==0){return 0;}
		else{
			printf("Line %d, column %d: Operator strconv.Atoi cannot be applied to types %s, %s\n",aux->args->linha,aux->args->coluna,idType,expType);
			return 1;
		}
	}
	if(aux->ret!=NULL){
		return checkReturn(aux->ret,fd);
		//verificar se o que se vai retornar coincide com o type da func
	}
	if(aux->forBlock!=NULL){
		return checkFor(aux->forBlock,fd);
		//verificar a validade da expression do for
	}
	if(aux->ifBlock!=NULL){
		return checkIf(aux->ifBlock,fd);
		//verificar a validade da expression do if
	}
	if(aux->multiple_s!=NULL){
		//func para statements
		list_statements* tmp;
		int errorM=0;
		for(tmp=aux->multiple_s; tmp; tmp=tmp->next){
			errorM+=checkStatement(tmp->state,fd);
		}
		return errorM;	
	}
	if(aux->assign!=NULL){
		return check_assign(aux,fd);
		
	}
	printf("Empty Statement\n");
	return 1;
}

int check_funcdec(is_funcdec* fd){
    int error=0;    
    if(fd!=NULL){
	   //percorrer varandstatements e ver tudo
	   is_varstatements* aux;
	   for(aux=fd->list_vs; aux; aux=aux->next){
		//verificar o resto dos statements
		if(aux->statement!=NULL){
			error+=checkStatement(aux->statement,fd);
		}
	   }
    }
    return error;
}

