#include "structures.h"
#include "functions.h"
#include "symbol_table.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

extern is_program* myprogram;
int varCount;
int label;
char salvador[10];
char* array[800];
int indice=0;

void generateStat(is_statement* stat,is_funcdec* fd);
int sizeString(char *str);
char* TypeConversor(char* str){
	if(str==NULL) return "i32";
	if(strcmp(str,"Int")==0 || strcmp(str,"int")==0) return "i32";
	if(strcmp(str,"Float32")==0 || strcmp(str,"float32")==0) return "double";
	if(strcmp(str,"Bool")==0 || strcmp(str,"bool")==0) return "i1";
	if(strcmp(str,"String")==0 || strcmp(str,"string")==0) return "i8";
	return str;
	
}

void generateGlobalVars(is_vardec* v){
	char * type = TypeConversor(v->type);
	is_vardecid* tmp;
	for(tmp=v->varspec_list;tmp;tmp=tmp->next){
		if(strcmp(type,"double")==0)printf("@%s = common global %s 0.0\n",tmp->id,type);
		else printf("@%s = common global %s 0\n",tmp->id,type);
	}
}

void generateVariable(is_vardec* v){
	char * type = TypeConversor(v->type);
	is_vardecid* tmp;
	for(tmp=v->varspec_list;tmp;tmp=tmp->next){
		printf("%%%s = alloca %s\n",tmp->id,type);
	}

}

//i32 double i1 string
char* typeExpression(is_expression* expr, is_funcdec* fd){
	if(expr->intlit!=NULL){
		return "i32";
	}
	if(expr->reallit!=NULL){
		return "double";
	}
	if(expr->id!=NULL){
		return TypeConversor(getVarType(expr->id,fd,expr->linha));
	}
	if(expr->funcinvoc!=NULL){
		return TypeConversor(getFuncType(expr->funcinvoc->id));
	}
	if(expr->operador!=NULL){
		if(strcmp(expr->operador,"Or")==0 || strcmp(expr->operador,"And")==0 || strcmp(expr->operador,"Lt")==0 || strcmp(expr->operador,"Gt")==0 || strcmp(expr->operador,"Le")==0 || strcmp(expr->operador,"Ge")==0 || strcmp(expr->operador,"Eq")==0 || strcmp(expr->operador,"Ne")==0){
			return "i1";
		}
		if(strcmp(expr->operador,"Mod")==0) return "i32";
		if(strcmp(expr->operador,"Div")==0 || strcmp(expr->operador,"Mul")==0 || strcmp(expr->operador,"Sub")==0 ){
			return typeExpression(expr->right,fd);
		}
		if(strcmp(expr->operador,"Add")==0){
			return typeExpression(expr->right,fd);
		}
	}
	return "not done";
}

char* OpConv(is_expression* expr,is_funcdec* fd){
	char * str = typeExpression(expr,fd);
	if(strcmp(str,"i32")==0){
		if(strcmp(expr->operador,"Mul")==0)return "mul";
		if(strcmp(expr->operador,"Add")==0)return "add";
		if(strcmp(expr->operador,"Sub")==0)return "sub";
		if(strcmp(expr->operador,"Mod")==0)return "srem";
		if(strcmp(expr->operador,"Div")==0)return "div";
	}else
	{
		if(strcmp(expr->operador,"Mul")==0)return "fmul";
		if(strcmp(expr->operador,"Add")==0)return "fadd";
		if(strcmp(expr->operador,"Sub")==0)return "fsub";
		if(strcmp(expr->operador,"Div")==0)return "fdiv";
	}
	if(strcmp(expr->operador,"And")==0)return "and";
	if(strcmp(expr->operador,"Or")==0)return "or";
	if(strcmp(expr->operador,"Lt")==0)return "lt";
	if(strcmp(expr->operador,"Gt")==0)return "gt";
	if(strcmp(expr->operador,"Le")==0)return "lte";
	if(strcmp(expr->operador,"Ge")==0)return "gte";
	if(strcmp(expr->operador,"Eq")==0)return "eq";
	if(strcmp(expr->operador,"Ne")==0)return "ne";
	return str;
}

int isParam(is_expression* expr,is_funcdec* fd){
	if(fd->params!=NULL){
		is_params* p;
		for(p=fd->params;p;p=p->next){
			if(strcmp(p->id,expr->id)==0)return 1;
		}
	}

	return 0;
}

char* typeParam(is_expression* expr,is_funcdec* fd){
	if(fd->params!=NULL){
		is_params* p;
		for(p=fd->params;p;p=p->next){
			if(strcmp(p->id,expr->id)==0)return p->type;
		}
	}

	return "bug params";
}
/*
char* prepareReal(char* str){
	char* aux =(char *)malloc(sizeof(char) * 200);
	if(str[0]=='.'){
		strcat(aux,"0");
		strcat(aux,str);
		return aux;
		
	}
	return str;

}*/

int isGlobal(char* str,int linha,is_funcdec* fd){
	
	is_varstatements* vs;
	for(vs=fd->list_vs;vs;vs=vs->next){
		if(vs->vardec!=NULL){
			is_vardecid* tmp;
			for(tmp=vs->vardec->varspec_list;tmp;tmp=tmp->next){
				if(strcmp(tmp->id,str)==0 && tmp->linha<linha){
					return 0;
				}
			}

		}
	}

	is_declaration_list* tmp;
	for(tmp=myprogram->dlist; tmp; tmp=tmp->next){
		if(tmp->v!=NULL){
			
			is_vardecid* aux;
			for(aux=tmp->v->varspec_list;aux;aux=aux->next){
				if(strcmp(aux->id,str)==0 ){
					return 1;
				}
			}

		
		}	   
	}
	return 0;

}


char* prepareExpression(is_expression* expr,is_funcdec* fd){
	if(expr->intlit!=NULL){
		return expr->intlit;
	}
	if(expr->reallit!=NULL){
		return expr->reallit;
	}
	if(expr->id!=NULL){
		
		char* type = typeExpression(expr,fd);
		if(isParam(expr,fd)==1){
			/*char * type= TypeConversor(typeParam(expr,fd));
			printf("store %s %%%d, %s* %%%s\n",type,++varCount,type,expr->id);
			*/
			sprintf(salvador,"%%%s",expr->id);
			return salvador;
			
		}
		if(isGlobal(expr->id,expr->linha,fd)==0){
			printf("%%%d = load %s, %s* %%%s\n",++varCount,type,type,expr->id);
		}else {
			printf("%%%d = load %s, %s* @%s\n",++varCount,type,type,expr->id);
		}
				
		sprintf(salvador,"%%%d",varCount);
		return salvador;
	}
	if(expr->funcinvoc!=NULL){
		list_expression* tmp;
		char* str= (char *)malloc(sizeof(char) * 200);
		for(tmp=expr->funcinvoc->list_expr;tmp;tmp=tmp->next){
			if(tmp->next!=NULL){
				strcat(str,typeExpression(tmp->expr,fd));
				strcat(str," ");
				strcat(str,prepareExpression(tmp->expr,fd));
				strcat(str,",");
			}
			else{
				strcat(str,typeExpression(tmp->expr,fd));
				strcat(str," ");
				strcat(str,prepareExpression(tmp->expr,fd));
			}
				
		}
		
		printf("%%%d = call %s @%s(%s)\n",++varCount,TypeConversor(getFuncType(expr->funcinvoc->id)),expr->funcinvoc->id,str);
		sprintf(salvador,"%%%d",varCount);
		return salvador;
	}
	if(expr->operador!=NULL){
		char * right =strdup(prepareExpression(expr->right,fd));
		char * left =strdup(prepareExpression(expr->left,fd));
		if(strcmp(expr->operador,"Or")==0 || strcmp(expr->operador,"And")==0 || strcmp(expr->operador,"Lt")==0 || strcmp(expr->operador,"Gt")==0 || strcmp(expr->operador,"Le")==0 || strcmp(expr->operador,"Ge")==0 || strcmp(expr->operador,"Eq")==0 || strcmp(expr->operador,"Ne")==0){
			printf("%%%d = icmp %s %s %s, %s\n",++varCount,OpConv(expr,fd),typeExpression(expr->right,fd),left,right);
			sprintf(salvador,"%%%d",varCount);
			return salvador;

		}		
		else{
			printf("%%%d = %s %s %s, %s\n",++varCount,OpConv(expr,fd),typeExpression(expr,fd),left,right);
			sprintf(salvador,"%%%d",varCount);
			return salvador;
		}
			
		
	}
	return "not done";
} 

void generatePrint(is_statement* stat,is_funcdec* fd){
	if(stat->print->strlit!=NULL){
		array[indice] = strdup(stat->print->strlit);
		printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([%d x i8], [%d x i8]* @.str%d, i32 0, i32 0))\n",++varCount,sizeString(array[indice]),sizeString(array[indice]),indice);
		indice++;
		return;
	}
	if(stat->print->expr!=NULL){
		char* type= typeExpression(stat->print->expr,fd);
		if(strcmp(type,"i32")==0 && stat->print->expr->intlit!=NULL){
			printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([4 x i8], [4 x i8]* @.intlit, i32 0, i32 0), i32 %s)\n",++varCount,prepareExpression(stat->print->expr,fd));
			return;
		}
		if(strcmp(type,"double")==0 && stat->print->expr->reallit!=NULL){
			printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([7 x i8], [7 x i8]* @.reallit, i32 0, i32 0), double %s)\n",++varCount,prepareExpression(stat->print->expr,fd));
			return;
		}
		if(strcmp(type,"i32")==0){
			printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([4 x i8], [4 x i8]* @.intlit, i32 0, i32 0), i32 %s)\n",++varCount,prepareExpression(stat->print->expr,fd));
			return;
		}
		if(strcmp(type,"double")==0){
			printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([7 x i8], [7 x i8]* @.reallit, i32 0, i32 0), double %s)\n",++varCount,prepareExpression(stat->print->expr,fd));
			return;
		}
		if(strcmp(type,"i1")==0){
			char *cond = strdup(prepareExpression(stat->print->expr,fd));
			char ifvar[20];
			sprintf(ifvar,"ifvar%d",label);
			
			char elsevar[20];
			sprintf(elsevar,"elsevar%d",label);
					
			char ifcont[20];
			sprintf(ifcont,"ifcont%d",label);
			printf("br i1 %s, label %%%s, label %%%s\n",cond,ifvar,elsevar);
			printf("%s:\n",ifvar);
			printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([6 x i8], [6 x i8]* @.true, i32 0, i32 0))\n",++varCount);
			printf("br label %%%s\n",ifcont);
			printf("%s:\n",elsevar);
			printf("%%%d = call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([7 x i8], [7 x i8]* @.false, i32 0, i32 0))\n",++varCount);
			printf("br label %%%s\n",ifcont);
			printf("%s:\n",ifcont);
			label++;
			return;			
			
		}
	}
	
}

void generateAssign(is_statement* stat,is_funcdec* fd){
	char* type= typeExpression(stat->assign->expr,fd);
		if(strcmp(type,"i32")==0 || strcmp(type,"double")==0 || strcmp(type,"i1")==0){
			if(isGlobal(stat->assign->id,stat->assign->linha,fd)==0)printf("store %s %s, %s* %%%s\n",typeExpression(stat->assign->expr,fd),prepareExpression(stat->assign->expr,fd),type,stat->assign->id);
			else printf("store %s %s, %s* @%s\n",typeExpression(stat->assign->expr,fd),prepareExpression(stat->assign->expr,fd),type,stat->assign->id);
			return;
		}
		if(strcmp(type,"i1")==0){
			typeExpression(stat->assign->expr,fd);
			prepareExpression(stat->assign->expr,fd);
			//printf("store %s %s, i1* %%%s\n",typeExpression(stat->assign->expr,fd),prepareExpression(stat->assign->expr,fd),stat->assign->id);
		}		
}

void generateIf(is_statement* stat,is_funcdec* fd){
	
	if(stat->ifBlock->list_state!=NULL){
		char *cond = strdup(prepareExpression(stat->ifBlock->expr,fd));	
		
		char ifvar[20];
		sprintf(ifvar,"ifvar%d",label);
		
		char elsevar[20];
		if(stat->ifBlock->list_els!=NULL)sprintf(elsevar,"elsevar%d",label);
				
		char ifcont[20];
		sprintf(ifcont,"ifcont%d",label);
		
		
		if(stat->ifBlock->list_els==NULL)printf("br i1 %s, label %%%s, label %%%s\n",cond,ifvar,ifcont);
		else printf("br i1 %s, label %%%s, label %%%s\n",cond,ifvar,elsevar);
		
		printf("%s:\n",ifvar);
		list_statements* tmp;
		for(tmp=stat->ifBlock->list_state;tmp;tmp=tmp->next){
			generateStat(tmp->state,fd);
		}
		printf("br label %%%s\n",ifcont);
		if(stat->ifBlock->list_els!=NULL){
			printf("%s:\n",elsevar);
			list_statements* tmp;
			for(tmp=stat->ifBlock->list_els;tmp;tmp=tmp->next){
				generateStat(tmp->state,fd);
			}
			printf("br label %%%s\n",ifcont);
		}
		printf("%s:\n",ifcont);
		label++;
	}
	
}

void generateFor(is_statement* stat,is_funcdec* fd){
	if(stat->forBlock->list_s!=NULL){
		varCount--;
		char condLabel[20];
		sprintf(condLabel,"condLabel%d",label);
		
		printf("br label %%%s\n",condLabel);
		char *cond = strdup(prepareExpression(stat->forBlock->expr,fd));
		
		char forLabel[20];
		sprintf(forLabel,"forLabel%d",label);
	
		char endLabel[20];
		sprintf(endLabel,"endLabel%d",label);
		
		printf("br i1 %s, label %%%s, label %%%s\n",cond,forLabel,endLabel);
		printf("%s:\n",forLabel);
		list_statements* tmp;
			for(tmp=stat->forBlock->list_s;tmp;tmp=tmp->next){
				generateStat(tmp->state,fd);
			}
		
		printf("br label %%%s\n",condLabel);
		printf("%s:\n",endLabel);
		label++;
	}
}


void generateParseArgs(is_statement* stat,is_funcdec* fd){
	printf("%%%d = alloca i32\n",++varCount);
	printf("%%%d = alloca i8**\n",++varCount);
	printf("store i32 %%0, i32* %%%d\n",varCount-1);
	printf("store i8** %%1, i8*** %%%d\n",varCount);
	varCount++;
	printf("%%%d = load i8**, i8*** %%%d\n",varCount,varCount-1);
	varCount++;
	printf("%%%d = getelementptr inbounds i8*, i8** %%%d, i64 %s\n",varCount,varCount-1,prepareExpression(stat->args->expr,fd));
	varCount++;
	printf("%%%d = load i8*, i8** %%%d\n",varCount,varCount-1);	
	varCount++;
	printf("%%%d = call i32 @atoi(i8* %%%d)\n",varCount,varCount-1);
	printf("store i32 %%%d, i32* %%%s\n",varCount,stat->args->id);	
	
		

}
void generateStat(is_statement* stat,is_funcdec* fd){
	if(stat->print!=NULL){
		generatePrint(stat,fd);
	}
	if(stat->funcinvoc!=NULL){
		list_expression* tmp;
		char str[200];
		for(tmp=stat->funcinvoc->list_expr;tmp;tmp=tmp->next){
			if(tmp->next!=NULL)
				sprintf(str,"%s %s,",typeExpression(tmp->expr,fd),prepareExpression(tmp->expr,fd));
			else
				sprintf(str,"%s %s",typeExpression(tmp->expr,fd),prepareExpression(tmp->expr,fd));
		}
		printf("%%%d = call %s @%s(%s)\n",++varCount,TypeConversor(getFuncType(stat->funcinvoc->id)),stat->funcinvoc->id,str);
	}
	if(stat->args!=NULL){
		generateParseArgs(stat,fd);		
	}
	if(stat->ret!=NULL){
		if(stat->ret->expr==NULL){printf("ret i32 0\n");}
		else printf("ret %s %s\n",typeExpression(stat->ret->expr,fd),prepareExpression(stat->ret->expr,fd));
		varCount++;
	}
	if(stat->forBlock!=NULL){
		generateFor(stat,fd);
	}
	if(stat->ifBlock!=NULL){
		generateIf(stat,fd);
	}
	if(stat->multiple_s!=NULL){
		list_statements* tmp;
		for(tmp=stat->multiple_s;tmp;tmp=tmp->next){
			generateStat(tmp->state,fd);
		}	
	}
	if(stat->assign!=NULL){
		generateAssign(stat,fd);
	}
}

void generateStatements(is_funcdec* fd){
	is_varstatements* tmp;
	
	for(tmp=fd->list_vs;tmp;tmp=tmp->next){
		if(tmp->vardec!=NULL){
			generateVariable(tmp->vardec);
		}
		if(tmp->statement!=NULL){
			generateStat(tmp->statement,fd);
		}
	}
}

void generateFunction(is_funcdec* fd){
	
	printf("define ");
	if(fd->type!=NULL)printf("%s ",TypeConversor(fd->type));
	else{
		printf("i32 ");	
	}
	printf("@%s(",fd->id);
	if(strcmp(fd->id,"main")==0){
		printf("i32, i8**");
	
	}
	if(fd->params!=NULL){
		//type %nome
		is_params* p;
		for(p=fd->params;p;p=p->next){
			if(p->next!=NULL)
				printf("%s %%%s,",TypeConversor(p->type),p->id);
			else
				printf("%s %%%s",TypeConversor(p->type),p->id);
			
		}
	}
	printf(") {\n");
	/*if(fd->params!=NULL){
		//type %nome
		is_params* p;
		for(p=fd->params;p;p=p->next){
			printf("%%%s = alloca %s\n",p->id,TypeConversor(p->type));		
		}
	}*/
	
	
	generateStatements(fd);
	if(fd->type==NULL || strcmp(fd->type,"Int")==0){
		printf("ret i32 0\n");
	}
	else if(strcmp(fd->type,"Float32")==0){
		printf("ret double 0.0\n");
	}

	printf("}\n");

}


int sizeString(char *str){
	int i;
	int count=2;
	for(i=0;i<strlen(str);i++){
		if(str[i]=='"'){
		}
		else if(str[i]=='\\'){
			
			i++;
			if(str[i]=='n'){count++;}
			else if(str[i]=='\\'){count++;}
			else if(str[i]=='t'){count++;}
			else if(str[i]=='f'){count++;}
			else if(str[i]=='r'){count++;}
			else if(str[i]=='\"'){count++;}
			else{count++;}				
		}
		else if(str[i]=='%'){
			count+=2;
		}
		else{
			count++;
		}
	}
	return count;
}

void printString(char *str){
	int i;
	printf("\"");
	for(i=0;i<strlen(str);i++){
		if(str[i]=='"'){
				
		}
		else if(str[i]=='\\'){
			i++;
			if(str[i]=='n'){printf("\\0A");}
			else if(str[i]=='\\'){printf("\\5C");}
			else if(str[i]=='t'){printf("\\09");}
			else if(str[i]=='f'){printf("\\0C");}
			else if(str[i]=='r'){printf("\\0D");}
			else if(str[i]=='\"'){printf("\\22");}
			else{printf("%c",str[i]);}
			
		}
		else if(str[i]=='%'){
			printf("%%%%");
		}
		else{
			printf("%c",str[i]);
		}
		
	}
	printf("\\0A");
	printf("\\00");
	printf("\"");

}

void printArray(){
	int i;	
	for(i=0;i<indice;i++){
		printf("@.str%d = private unnamed_addr constant [%d x i8] c",i,sizeString(array[i]));
		printString(array[i]);
		printf("\n");
	}

}




void generate(){
	
	printf("@.intlit= private unnamed_addr constant [4 x i8] c\"%%d\\0A\\00\"\n");
	printf("@.reallit= private unnamed_addr constant [7 x i8] c\"%%0.8f\\0A\\00\"\n");
	printf("@.true= private unnamed_addr constant [6 x i8] c\"true\\0A\\00\"\n");	
	printf("@.false= private unnamed_addr constant [7 x i8] c\"false\\0A\\00\"\n");
	is_declaration_list* tmp;
	for(tmp=myprogram->dlist; tmp; tmp=tmp->next){
		if(tmp->v!=NULL){
			generateGlobalVars(tmp->v);
		}	   
	}
	
	for(tmp=myprogram->dlist; tmp; tmp=tmp->next){
		varCount=0;
		label=1;
		if(tmp->fd!=NULL && strcmp(tmp->fd->id,"main")!=0){
			
			generateFunction(tmp->fd);
		}	   
	}
	for(tmp=myprogram->dlist; tmp; tmp=tmp->next){
		varCount=2;
		label=1;
		if(tmp->fd!=NULL && strcmp(tmp->fd->id,"main")==0){
			
			generateFunction(tmp->fd);
			varCount++;
		}	   
	}
	printArray();
	printf("declare i32 @printf(i8*, ...)\n");
	printf("declare i32 @atoi(i8*)\n");
	
		
		
}



