#include "structures.h"
#include "symbol_table.h"

int check_program(is_program* p);
int check_vardec(is_vardec* var);
int check_funcdec(is_funcdec* fd);
int check_funcdecSt(is_funcdec* fd);
