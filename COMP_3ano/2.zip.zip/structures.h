#ifndef STRUCTURES_H
#define STRUCTURES_H

typedef struct _expression{
	struct _expression* right;
	struct _expression* left;
	char * operador;
	char * intlit;
	char* reallit;
	char * id;
	struct _list_base *base;	
	struct _funcinvoc* funcinvoc;
}is_expression;



typedef struct _list_base{
	char* strBase;
	struct _list_base* next;
}list_base;

typedef struct _statement{
	struct _print* print;
	struct _funcinvoc* funcinvoc;
	struct _parseargs* args;
	struct _return* ret; 
	struct _for * forBlock;
	struct _if * ifBlock;
	struct _list_statements * multiple_s;
	struct _assign* assign;
} is_statement;

typedef struct _list_statements{
	struct _statement* state;
	struct _list_statements * next;
}list_statements; /*so usado para block if e for*/

typedef struct _list_expr{
	struct _expression* expr;
	struct _list_expr * next;
}list_expression;

typedef struct _funcinvoc{
	char* id;
	struct _list_expr* list_expr;
}is_funcinvoc;

typedef struct _parseargs{
	char* id;
	struct _expression* expr;
}is_parseargs;

/*Estrutra das expressẽs*/
typedef struct _return{
	/* Se a estrurura statement tiver ret a não null, é porque ha return, e se expr for NULL é return void*/
	struct _expression* expr;

}is_return;

typedef struct _for{
	struct _expression* expr;
	struct _list_statements * list_s;
}is_for;

typedef struct _assign{
	char*id;
	struct _expression* expr;
}is_assign;
typedef struct _if{
	struct _expression* expr;
	struct _list_statements* list_state;
	struct _list_statements* list_els;
}is_if;

typedef struct _vardecid {
	char* id;
	struct _vardecid* next;	
} is_vardecid;

typedef struct _varstatements{
	struct _vardec* vardec;
	struct _statement * statement;
	struct _varstatements* next;
} is_varstatements;

typedef struct _vardec { /*insere feito*/
        char* type;
	struct _vardecid* varspec_list;
        //struct _vardec* next; /*possivel bug de listas*/
} is_vardec;

typedef struct _params { /*insere feito*/
	char* type;
	char* id;
        struct _params* next;
} is_params;

typedef struct _funcdec { /*insere feito*/
	struct _params* params;
	char* type;
	char *id;
	struct _varstatements* list_vs;
        //struct _funcdec* next;
} is_funcdec;

typedef struct _print{ /* nao tem next(terminal)*/
	char* strlit;
	struct _expression* expr;
}is_print;
/*
typedef struct _listexpr{
	struct _expression* expr;
	struct _listexpr* next;
	
}is_listexpr;
*/
typedef struct _declaration_list { /*insere feito*/
        struct _vardec* v;
	struct _funcdec* fd;
        struct _declaration_list* next;
} is_declaration_list;

typedef struct _program { 
    struct _declaration_list* dlist;
} is_program;

#endif
