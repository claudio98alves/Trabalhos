#include "structures.h"

is_program* insert_program(is_declaration_list* dl);
is_declaration_list* insert_declaration_list(is_declaration_list* head, is_vardec* var, is_funcdec* funcdec);
is_vardec* insert_vardec(char* strid,is_vardecid* varsid, char* strtype);
is_vardecid* insert_moreids(is_vardecid* head,char* strid);
is_funcdec* insert_funcdec(char* strid, is_params* parameters, char* strtype, is_varstatements* body);
is_params* insert_params(char* strid, char* strtype, is_params* lista);
is_params* insert_moreparams(char* strid, char* strtype,is_params* head);
is_varstatements* insert_varstatements(is_varstatements* head, is_varstatements* novo);
is_varstatements* create_varstatements(is_statement* state, is_vardec* var);
is_statement* printState(is_expression* expre, char* string);
is_funcinvoc* insert_funcInvoc(char* strid, list_expression* head);
is_statement* statement_funcinvoc(is_funcinvoc* fi);
list_expression* insert_listExpression(is_expression* exp, list_expression* lista);
is_statement* insert_parseargs(char* strid, is_expression* exp);
is_statement* insert_return(is_expression* exp);
is_statement* insert_forBlock(is_expression* exp, list_statements* lista);
list_statements* insert_multiState(list_statements* head,is_statement* s);
list_statements* special_else(list_statements* s);
is_statement* insert_ifBlock(is_expression* exp,list_statements* if_lista,list_statements* else_lista);
is_statement* multiS_to_statement(list_statements* head);
is_statement* insert_assign(char* strid, is_expression* exp);
is_expression* create_expression(char* strint,char* strreal,char* strid,is_funcinvoc* fi);
is_expression* insert_expression(is_expression* filhoL, char* strop, is_expression* filhoR);
is_expression* add_Base(list_base* baseExp,is_expression* exp);
list_base* concat_Base(list_base* head, char* strbase);
/**/


void showtree(is_program* program);
