#include "structures.h"
#include "functions.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

is_program* insert_program(is_declaration_list* dl)
{
	is_program* ip=(is_program*)malloc(sizeof(is_program));

	ip->dlist=dl;
	return ip;
} 

is_declaration_list* insert_declaration_list(is_declaration_list* head, is_vardec* var, is_funcdec* funcdec)
{	
	if (var!=NULL){
		is_declaration_list* id = (is_declaration_list*)malloc(sizeof(is_declaration_list));
		is_declaration_list* tmp;
		
		id->v=var;
		id->next=NULL;

		if(head==NULL)
               		return id;

		for(tmp=head; tmp->next; tmp=tmp->next)
		;/*encontra o null da list*/
        	tmp->next=id;/*insere no fim*/
        	return head;
	}
	else{
		is_declaration_list* id = (is_declaration_list*)malloc(sizeof(is_declaration_list));
		is_declaration_list* tmp;
		
		id->fd=funcdec;
		id->next=NULL;

		if(head==NULL)
               		return id;

		for(tmp=head; tmp->next; tmp=tmp->next)
		;/*encontra o null da list*/
        	tmp->next=id;/*insere no fim*/
        	return head;
	}     
}


is_vardec* insert_vardec(char* strid,is_vardecid* varsid, char* strtype){

	is_vardec* iv = (is_vardec*)malloc(sizeof(is_vardec));
	is_vardecid* ivdi = (is_vardecid*)malloc(sizeof(is_vardecid));

	iv->type=(char*)strdup(strtype);

	ivdi->next=varsid;
	ivdi->id=(char*)strdup(strid);
	
	iv->varspec_list=ivdi;
	return iv;
}


is_vardecid* insert_moreids(is_vardecid* head,char* strid){
	is_vardecid* ivdi = (is_vardecid*)malloc(sizeof(is_vardecid));
	is_vardecid* tmp;

	ivdi->id=(char*)strdup(strid);
	ivdi->next=NULL;

	if(head==NULL)
		return ivdi;
	for(tmp=head; tmp->next; tmp=tmp->next)
	;
        tmp->next=ivdi;

        return head;
	
}

is_funcdec* insert_funcdec(char* strid, is_params* parameters, char* strtype, is_varstatements* body){
	is_funcdec* fd = (is_funcdec*)malloc(sizeof(is_funcdec));
	if(strtype!=NULL)
		fd->type=(char*)strdup(strtype);
	else
		fd->type=NULL;

	fd->id=(char*)strdup(strid);
	fd->params=parameters;
	fd->list_vs=body;
	return fd;
}

is_params* insert_params(char* strid, char* strtype, is_params* lista){
	
	is_params* iparams = (is_params*)malloc(sizeof(is_params));
	
	iparams->id=(char*)strdup(strid);	
	iparams->type=(char*)strdup(strtype);
	iparams->next=lista;
	
	return iparams;	
}

is_params* insert_moreparams(char* strid, char* strtype,is_params* head){
	
	is_params* iparams = (is_params*)malloc(sizeof(is_params));
	is_params* tmp;

	iparams->id=(char*)strdup(strid);
	iparams->type=(char*)strdup(strtype);
	iparams->next=NULL;
	
	if(head==NULL)
		return iparams;
	for(tmp=head; tmp->next; tmp=tmp->next)
	;
        tmp->next=iparams;

        return head;
}

is_varstatements* insert_varstatements(is_varstatements* head, is_varstatements* novo){
	is_varstatements* tmp;
	if(head==NULL)
		return novo;
	for(tmp=head; tmp->next; tmp=tmp->next)
	;
        tmp->next=novo;

        return head;
}

is_varstatements* create_varstatements(is_statement* state, is_vardec* var){
	is_varstatements* node = (is_varstatements*)malloc(sizeof(is_varstatements));
	if( state!=NULL){
		node->statement=state;
		node->next=NULL;
		node->vardec=NULL;
		return node;
	}
	else{ // É vardec
		node->vardec= var;
		node->next=NULL;
		node->statement=NULL;
		return node;
	}
}

is_statement* printState(is_expression* expre, char* string){
	is_print* no= (is_print*)malloc(sizeof(is_print));
	is_statement* no2= (is_statement*)malloc(sizeof(is_statement));
	
	if( expre!=NULL){
			
		no->expr= expre;
		no->strlit=NULL;
		no2->print=no;
		return no2;
	}
	else{ // É vardec
		no->strlit=(char*)strdup(string);
		no->expr=NULL;
		no2->print=no;
		return no2;
	}

}

is_funcinvoc* insert_funcInvoc(char* strid, list_expression* head){

	is_funcinvoc* no =(is_funcinvoc*)malloc(sizeof(is_funcinvoc));	
	
	no->id=(char*)strdup(strid);
	no->list_expr=head;

	return no;
}

is_statement* statement_funcinvoc(is_funcinvoc* fi){
	is_statement* node= (is_statement*)malloc(sizeof(is_statement));
	node->funcinvoc=fi;
	return node;
}


list_expression* insert_listExpression(is_expression* exp, list_expression* lista){
	list_expression* node =(list_expression*)malloc(sizeof(list_expression));
	node->expr=exp;
	node->next=lista;
	return node;
}

is_statement* insert_parseargs(char* strid, is_expression* exp){
	is_statement* node =(is_statement*)malloc(sizeof(is_statement));
		
	is_parseargs* parg=(is_parseargs*)malloc(sizeof(is_parseargs));
	parg->id=(char*)strdup(strid);		
	parg->expr=exp;

	node->args=parg;	
	return node;
}

is_statement* insert_return(is_expression* exp){
	is_statement* node =(is_statement*)malloc(sizeof(is_statement));
	is_return* retur=(is_return*)malloc(sizeof(is_return));
	
	retur->expr=exp;
	node->ret=retur;
	return node;
}

is_statement* insert_forBlock(is_expression* exp, list_statements* lista){
	is_statement* node =(is_statement*)malloc(sizeof(is_statement));
	is_for* fBlock=(is_for*)malloc(sizeof(is_for));
	
	fBlock->expr=exp;
	fBlock->list_s=lista;

	node->forBlock=fBlock;
	return node;
}



list_statements* insert_multiState(list_statements* head,is_statement* s){
	list_statements* node =(list_statements*)malloc(sizeof(list_statements));
	list_statements* tmp;

	node->state=s;
	node->next=NULL;

	if(head==NULL)
		return node;
	for(tmp=head; tmp->next; tmp=tmp->next)
	;
        tmp->next=node;

        return head;
}
list_statements* special_else(list_statements* s){
	if(s!=NULL)
		return s;
	list_statements* node= (list_statements*)malloc(sizeof(list_statements));
	return node;

}

is_statement* insert_ifBlock(is_expression* exp,list_statements* if_lista,list_statements* else_lista ){
	is_statement* node =(is_statement*)malloc(sizeof(is_statement));

	is_if* iBlock = (is_if*)malloc(sizeof(is_if));
	
	iBlock->expr=exp;
	iBlock->list_state=if_lista;
	iBlock->list_els=else_lista;
		
	node->ifBlock=iBlock;
	return node;
}

is_statement* multiS_to_statement(list_statements* head){
	is_statement* node =(is_statement*)malloc(sizeof(is_statement));
	node->multiple_s=head;
	return node;
}

is_statement* insert_assign(char* strid, is_expression* exp){
	is_statement* node =(is_statement*)malloc(sizeof(is_statement));

	is_assign* ass = (is_assign*)malloc(sizeof(is_assign));
	ass->id=(char*)strdup(strid);
	ass->expr=exp;

	node->assign=ass;	
	return node;
}


is_expression* create_expression(char* strint,char* strreal,char* strid,is_funcinvoc* fi){
	is_expression* node =(is_expression*)malloc(sizeof(is_expression));
	if(strint!=NULL){
		node->intlit=(char*)strdup(strint);
		return node;	
	}
	if(strreal!=NULL){
		node->reallit=(char*)strdup(strreal);
		return node;
	}
	if(strid!=NULL){
		node->id=(char*)strdup(strid);
		return node;
	}
	if(fi!=NULL){
		node->funcinvoc=fi;
		return node;		
	}
	/*just in case :)*/
	printf("BIG ERROR\n");
	return NULL;
}

is_expression* insert_expression(is_expression* filhoL, char * strop,is_expression* filhoR){
	is_expression* node =(is_expression*)malloc(sizeof(is_expression));

	node->left=filhoL;
	node->operador=(char*)strdup(strop);
	node->right=filhoR;
	return node;
}

is_expression* add_Base(list_base* baseExp,is_expression* exp){
	if(exp->base==NULL){
		exp->base=baseExp;
		return exp;
	}
	else if(baseExp!=NULL){/*inserir baseExp no inicio da lista de bases de exp*/
		list_base* tmp=baseExp;
		for(; tmp->next; tmp=tmp->next)
		;
		tmp->next=exp->base;
		exp->base=baseExp;
		return exp;
	}
	return exp;
}

list_base* concat_Base(list_base* head, char* strbase){
	list_base* node =(list_base*)malloc(sizeof(list_base));
	list_base* tmp;
	node->strBase=(char*)strdup(strbase);
	if(head==NULL)
		return node;
	for(tmp=head; tmp->next; tmp=tmp->next)
	;
        tmp->next=node;

        return head;
}



int nivel=0;

void printpontos(int p){
	int i;	
	for(i=0;i<p*2;i++){
	printf(".");
	}
}

void print_expression(is_expression* exp){
	
	/*se nao tiver operador é final*/
	if(exp->operador==NULL){
		if(exp->intlit!=NULL){
			if(exp->base!=NULL){
				int count = 0;
				list_base* tmpB=exp->base;
				while(tmpB!=NULL){
					printpontos(nivel);
					printf("%s\n",tmpB->strBase);
					nivel++;count++;
					tmpB=tmpB->next;
				}
				printpontos(nivel);
				printf("IntLit(%s)\n",exp->intlit);
				nivel=nivel-count;
			}
			else{
				printpontos(nivel);
				printf("IntLit(%s)\n",exp->intlit);		
			}
			return;				
		}
		if(exp->reallit!=NULL){
			if(exp->base!=NULL){
				int count = 0;
				list_base* tmpB =exp->base;
				while(tmpB!=NULL){
					printpontos(nivel);
					printf("%s\n",tmpB->strBase);
					nivel++;count++;
					tmpB=tmpB->next;
				}
				printpontos(nivel);
				printf("RealLit(%s)\n",exp->reallit);
				nivel=nivel-count;
			}
			else{
				printpontos(nivel);
				printf("RealLit(%s)\n",exp->reallit);
			}
			return;
		}
		if(exp->id!=NULL){
			if(exp->base!=NULL){


				int count = 0;
				list_base* tmpB =exp->base;
				while(tmpB!=NULL){
					printpontos(nivel);
					printf("%s\n",tmpB->strBase);
					nivel++;count++;
					tmpB=tmpB->next;
				}
				printpontos(nivel);
				printf("Id(%s)\n",exp->id);
				nivel=nivel-count;
			}
			else{
				printpontos(nivel);
				printf("Id(%s)\n",exp->id);
			}
			return;
		}
		if(exp->funcinvoc!=NULL){
			if(exp->base!=NULL){
				
				int count = 0;
				list_base* tmpB =exp->base;
				while(tmpB!=NULL){
					printpontos(nivel);
					printf("%s\n",tmpB->strBase);
					nivel++;count++;
					tmpB=tmpB->next;
					
				}

				printpontos(nivel);	
				printf("Call\n");
				nivel++;
			
				printpontos(nivel);	
				printf("Id(%s)\n",exp->funcinvoc->id);
				list_expression* tmp=exp->funcinvoc->list_expr;
				while(tmp!=NULL){
					if(tmp->expr!=NULL){
						print_expression(tmp->expr);			
					}
					tmp=tmp->next;
				}
				nivel=nivel-count;
				nivel--;
			}
			else{
				printpontos(nivel);	
				printf("Call\n");
				nivel++;
			
				printpontos(nivel);	
				printf("Id(%s)\n",exp->funcinvoc->id);
				list_expression* tmp=exp->funcinvoc->list_expr;
				while(tmp!=NULL){
					if(tmp->expr!=NULL){
						print_expression(tmp->expr);			
					}
					tmp=tmp->next;
				}
				nivel--;
		
			}
			return;
		}
		
	}
	else if(exp->operador!=NULL){
		if(exp->base!=NULL){
			int count = 0;
			list_base* tmpB =exp->base;
			while(tmpB!=NULL){
				printpontos(nivel);
				printf("%s\n",tmpB->strBase);
				nivel++;count++;
				tmpB=tmpB->next;		
			}
			printpontos(nivel);
			printf("%s\n",exp->operador);
			nivel++;
			print_expression(exp->left);
			print_expression(exp->right);	
			nivel--;
			nivel=nivel-count;
			return;
		}
		else{
			printpontos(nivel);
			printf("%s\n",exp->operador);
			nivel++;
			print_expression(exp->left);
			print_expression(exp->right);	
			nivel--;			
			return;
		}
	}
	printf("BIG ERROR EXP\n");
}


int statement_empty(is_statement* s){
	if(s->print!=NULL){return 1;}
	if(s->funcinvoc!=NULL){return 1;}
	if(s->args!=NULL){return 1;}
	if(s->ret!=NULL){return 1;}
	if(s->forBlock!=NULL){return 1;}
	if(s->ifBlock!=NULL){return 1;}
	if(s->multiple_s!=NULL){return 1;}
	if(s->assign!=NULL){return 1;}
	return 0;
}

void print_statement(is_statement* s){
	if(s->print!=NULL){
		
		printpontos(nivel);	
		printf("Print\n");
		nivel++;
		if(s->print->strlit!=NULL){
			printpontos(nivel);	
			printf("StrLit(%s)\n",s->print->strlit);	
		}
		if(s->print->expr!=NULL){
			print_expression(s->print->expr);	
		}
		nivel--;
		return;
	}
	if(s->funcinvoc!=NULL){
		/*funcInvocation*/
		printpontos(nivel);	
		printf("Call\n");
		nivel++;
		
		printpontos(nivel);	
		printf("Id(%s)\n",s->funcinvoc->id);
		list_expression* tmp=s->funcinvoc->list_expr;
		while(tmp!=NULL){
			if(tmp->expr!=NULL){
				print_expression(tmp->expr);			
			}
			tmp=tmp->next;
		}
		nivel--;
		return;
	}
	if(s->args!=NULL){
		printpontos(nivel);	
		printf("ParseArgs\n");
		nivel++;
		printpontos(nivel);	
		printf("Id(%s)\n",s->args->id);
		print_expression(s->args->expr);			
		nivel--;
		return;
	}
	if(s->ret!=NULL){
		printpontos(nivel);	
		printf("Return\n");
		nivel++;
		if(s->ret->expr!=NULL){
			print_expression(s->ret->expr);			
		}
		nivel--;
		return;
	}
	if(s->forBlock!=NULL){
		printpontos(nivel);	
		printf("For\n");
		nivel++;
		if(s->forBlock->expr!=NULL)
			print_expression(s->forBlock->expr);
		printpontos(nivel);	
		printf("Block\n");
		nivel++;
		list_statements* tmp = s->forBlock->list_s;
		while(tmp!=NULL){/*descer nivel??*/
			print_statement(tmp->state);
			tmp=tmp->next;
		}
		nivel--;
		nivel--;		
		return;
	}
	if(s->ifBlock!=NULL){
		
		printpontos(nivel);	
		printf("If\n");
		nivel++;		
		print_expression(s->ifBlock->expr);
		printpontos(nivel);	
		printf("Block\n");
		nivel++;
		list_statements* tmp = s->ifBlock->list_state;
		while(tmp!=NULL){/*descer nivel??*/
			print_statement(tmp->state);
			tmp=tmp->next;
		}
		nivel--;

		if(s->ifBlock->list_els!=NULL){
			printpontos(nivel);	
			printf("Block\n");
			nivel++;
			list_statements* tmp2 = s->ifBlock->list_els;
			while(tmp2!=NULL){/*descer nivel??*/
				if(tmp2->state!=NULL)
					print_statement(tmp2->state);
				tmp2=tmp2->next;
			}		
			nivel--;
		}
		else{
			printpontos(nivel);	
			printf("Block\n");
		}


		nivel--;		
		return;
	}
	if(s->multiple_s!=NULL){
		/*preciso de blocks??*/
		list_statements* tmpcount = s->multiple_s;
		int a=0;
		while(tmpcount!=NULL){/*descer nivel??*/
			a=a+statement_empty(tmpcount->state);
			tmpcount=tmpcount->next;
		}
		if(a>=2){
			
			printpontos(nivel);	
			printf("Block\n");	
			nivel++;
		}
		/*blocks*/



		list_statements* tmp = s->multiple_s;
		while(tmp!=NULL){/*descer nivel??*/
			print_statement(tmp->state);
			tmp=tmp->next;
		}

		if(a>=2){
		nivel--;		
		}
		
		return;
	}
	if(s->assign!=NULL){
		
		printpontos(nivel);	
		printf("Assign\n");
		nivel++;
		
		printpontos(nivel);	
		printf("Id(%s)\n",s->assign->id);
		print_expression(s->assign->expr);
		
		nivel--;
		return;
	}
}


void print_vardec(is_vardec* v){
	
	char * aux=(char*)strdup(v->type);
	is_vardecid* tmp=v->varspec_list;
	nivel++;
	while(tmp!=NULL){
		nivel--;
		printpontos(nivel);
		printf("VarDecl\n");
		nivel++;
		printpontos(nivel);	
		printf("%s\n",aux);
		printpontos(nivel);	
		printf("Id(%s)\n",tmp->id);
		tmp=tmp->next;
	}
	nivel--;
	return;
	
}
void print_varstatements(is_varstatements* vs){
	is_varstatements* tmp = vs;
	while(tmp!=NULL){
		if(tmp->vardec!=NULL){
			print_vardec(tmp->vardec);
		}
		if(tmp->statement!=NULL){
			print_statement(tmp->statement);
		}
		tmp=tmp->next;
	}
	

}

void print_funcdec(is_funcdec* fd){
	
	printpontos(nivel);
	printf("FuncDecl\n");
	nivel++;
	
	printpontos(nivel);
	printf("FuncHeader\n");

	nivel++;

	printpontos(nivel);
	printf("Id(%s)\n",fd->id);
	if(fd->type!=NULL){

		printpontos(nivel);
		printf("%s\n",fd->type);	

	}
	printpontos(nivel);	
	printf("FuncParams\n");
	
	if(fd->params!=NULL){
		nivel++;
		is_params* tmp = fd->params;
		nivel++;
		while(tmp!=NULL){
			nivel--;
			printpontos(nivel);	
			printf("ParamDecl\n");
			nivel++;
			printpontos(nivel);	
			printf("%s\n",tmp->type);
			printpontos(nivel);	
			printf("Id(%s)\n",tmp->id);
			
			tmp=tmp->next;
		}
		nivel--;
		nivel--;
	}
	
	nivel--;
	
	
	printpontos(nivel);	
	printf("FuncBody\n");
	nivel++;
	if(fd->list_vs!=NULL){
		print_varstatements(fd->list_vs);
	}
	nivel--;
	/*fim funcbody*/
	nivel--;/*funcDecl*/	
}







void showtree(is_program* program){
	printf("Program\n");
	nivel++;
	if(program->dlist==NULL){
		return;
	}
	
	is_declaration_list* tmp;
	tmp=program->dlist;
	while(tmp!=NULL){	
		if(tmp->v!=NULL){
			
			print_vardec(tmp->v);
		}
		if(tmp->fd!=NULL){
			print_funcdec(tmp->fd);
		}		
		tmp=tmp->next;	
	}
	return;
	
}












