#include "structures.h"
#include "symbol_table.h"

void generate();
