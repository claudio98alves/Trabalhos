#include "symbol_table.h"
#include<stdlib.h>
#include<string.h>
#include<stdio.h>

extern table_element* symtab;
int search_func(is_funcdec* func);
int insert_var(is_vardec* var){
	table_element *newSymbol=(table_element*) malloc(sizeof(table_element));
	int canAdd=0;
	is_vardectab* iv = (is_vardectab*)malloc(sizeof(is_vardectab));
	is_vardecidtab* ivdi = (is_vardecidtab*)malloc(sizeof(is_vardecidtab));
	iv->varspec_list=ivdi;
	is_vardecid* tmpid;
	int error=0;
	
	for(tmpid=var->varspec_list; tmpid; tmpid=tmpid->next){
		
		if(search_varInsert(tmpid->id,NULL)==0){ //procura na symtab scope global
			
			/*posso inserir na symtab*/
			if(canAdd==0){
				iv->type=(char*)strdup(var->type);
				ivdi->id=(char*)strdup(tmpid->id);
				ivdi->linha=tmpid->linha;
				ivdi->coluna=tmpid->coluna;
				ivdi->utilizado=0;	
				canAdd=1;				
			}
			else{
			
				is_vardecidtab* aux;
				int flag=0;
				for(aux=ivdi; aux->next; aux=aux->next){
					if(strcmp(aux->id,tmpid->id)==0){
						flag=1;
						printf("Line %d, column %d: Symbol %s already defined\n",tmpid->linha,tmpid->coluna,tmpid->id);
						error++;
					}
				}/*inserir no fim da lista*/
				if(flag==0){
					aux->next=(is_vardecidtab*)malloc(sizeof(is_vardecidtab));
					aux->next->id=(char*)strdup(tmpid->id);
					aux->next->linha=tmpid->linha;
					aux->next->coluna=tmpid->coluna;
					aux->next->utilizado=0;
				}
				
			}
		}
		else{
			printf("Line %d, column %d: Symbol %s already defined\n",tmpid->linha,tmpid->coluna,tmpid->id);
			error++;
		}
	}
	if(canAdd==1){
		newSymbol->v=iv;
		table_element* tab;
		if(symtab==NULL){
			symtab=newSymbol;
			
		}
		else{
			for(tab=symtab; tab->next; tab=tab->next)
			;/*inserir no fim*/
			tab->next=newSymbol;
		}
	}
	return error;
}

int checkVars(){
	table_element* tab;
	int error=0;
	for(tab=symtab; tab; tab=tab->next){
		/*if(tab->v!=NULL){
			is_vardecidtab* tmp;
			for(tmp=tab->v->varspec_list;tmp;tmp=tmp->next){
				if(tmp->utilizado!=1){
					printf("Line %d, column %d: Symbol %s declared but never used\n",tmp->linha,tmp->coluna,tmp->id);
					error++;
				}
			}
		}*/
		if(tab->fd!=NULL){
			is_listvardec* aux;
			for(aux=tab->fd->lista_var; aux; aux=aux->next){
				is_vardecidtab* tmp;
				for(tmp=aux->var->varspec_list;tmp;tmp=tmp->next){
					if(tmp->utilizado!=1){
						printf("Line %d, column %d: Symbol %s declared but never used\n",tmp->linha,tmp->coluna,tmp->id);
					error++;
					}
				}
			}
		}
	}
	return error;
	

}

table_element * insert_func(is_funcdec* fd){
	table_element *newSymbol=(table_element*) malloc(sizeof(table_element));
	if(fd==NULL)return NULL;
	
	if(search_func(fd)==0){
		is_funcEl* el = (is_funcEl*)malloc(sizeof(is_funcEl));
		el->params=fd->params;
		if(fd->type!=NULL){el->type=(char*)strdup(fd->type);}		
		el->id=(char*)strdup(fd->id);
		el->linha=fd->linha;
		newSymbol->fd=el;
		table_element* tab;
		if(symtab==NULL){
			symtab=newSymbol;
			return newSymbol;
		}
		
		for(tab=symtab; tab->next; tab=tab->next)
		;//inserir no fim
		tab->next=newSymbol;
		return newSymbol;
	}
	else{
	//already defined function
		return NULL;
	}
	
	
}
void markId(char* str, is_funcdec* fd,int linha){
		//procurar o type da varaivel str na parte global e na fd
	char *fName = fd->id;
	is_vardecidtab *auxU=NULL;
	//procurar na global e na func
	table_element* tab;	
	for(tab=symtab; tab; tab=tab->next){
		if(tab->v!=NULL){
			is_vardecidtab* aux;
			for(aux=tab->v->varspec_list; aux; aux=aux->next){
				if(strcmp(str,aux->id)==0){auxU=aux;}
			}
		}
		else if(strcmp(fName,tab->fd->id)==0){
			is_listvardec* vars;
			for(vars=tab->fd->lista_var; vars; vars=vars->next){
				is_vardecidtab* v;
				for(v=vars->var->varspec_list; v; v=v->next){
					if(strcmp(str,v->id)==0){
						if(linha > v->linha){
										
						v->utilizado=1;}
					}
				}
			}
		}
	}
	if(auxU!=NULL){
		auxU->utilizado=1;
	}

}

int insert_varInFunc(table_element* symbol,is_vardec* var){
	//falta verificar a existencia dessa var nos params
	
	int canAdd=0;
	is_vardectab* iv = (is_vardectab*)malloc(sizeof(is_vardectab));
	is_vardecidtab* ivdi = (is_vardecidtab*)malloc(sizeof(is_vardecidtab));
	iv->varspec_list=ivdi;
	is_vardecid* tmpid;
	is_listvardec* elLista = (is_listvardec*)malloc(sizeof(is_listvardec));
	int error=0;
	for(tmpid=var->varspec_list; tmpid; tmpid=tmpid->next){
		
		if(search_varInsert(tmpid->id,symbol->fd->id)==0){ //procura na symtab
			//posso inserir na symtab
			if(canAdd==0){
				iv->type=(char*)strdup(var->type);
				ivdi->id=(char*)strdup(tmpid->id);
				ivdi->linha=tmpid->linha;
				ivdi->coluna=tmpid->coluna;
				ivdi->utilizado=0;	
				canAdd=1;				
			}
			else{
			
				
				is_vardecidtab* aux;
				int flag=0;
				for(aux=ivdi; aux->next; aux=aux->next){
					if(strcmp(aux->id,tmpid->id)==0){
						flag=1;
						printf("Line %d, column %d: Symbol %s already defined\n",tmpid->linha,tmpid->coluna,tmpid->id);
						error++;
					}
				}/*inserir no fim da lista*/
				if(flag==0){
					aux->next=(is_vardecidtab*)malloc(sizeof(is_vardecidtab));
					aux->next->id=(char*)strdup(tmpid->id);
					aux->next->linha=tmpid->linha;
					aux->next->coluna=tmpid->coluna;
					aux->next->utilizado=0;
				}
			}
		}
		else{
			
			printf("Line %d, column %d: Symbol %s already defined\n",tmpid->linha,tmpid->coluna,tmpid->id);
			error++;
		}
	}
	if(canAdd==1){
		elLista->var=iv;
		if(symbol->fd->lista_var==NULL){
			
			symbol->fd->lista_var=elLista;
		}
		else{
			is_listvardec* aux;
			for(aux=symbol->fd->lista_var; aux->next; aux=aux->next)
			;//inserir no fim
			aux->next=elLista;
		}
	}
	return error;
}

int search_func(is_funcdec* func){
	table_element* tab;
	if(symtab==NULL)return 0;
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL){
			
			if(strcmp(func->id,tab->fd->id)==0){
				printf("Line %d, column %d: Symbol %s already defined\n",func->linha,func->coluna,func->id);
				return 1;
			}
		}
		if(tab->v!=NULL){
			is_vardecidtab* aux;
			for(aux=tab->v->varspec_list;aux;aux=aux->next){
				if(strcmp(aux->id,func->id)==0){
					printf("Line %d, column %d: Symbol %s already defined\n",func->linha,func->coluna,func->id);
					return 1;
			
				}
			}
		}
	}
	
	
	return 0;
}


int check_search_func(is_funcdec* func){
	table_element* tab;
	if(symtab==NULL)return 0;
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL){
			if(strcmp(func->id,tab->fd->id)==0){
				return tab->fd->linha;
			}
		}
	}
	
	
	return 0;
}

int check_ffinvoc(char* str){
	table_element* tab;
	if(symtab==NULL)return 0;
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL){
			if(strcmp(str,tab->fd->id)==0){
				return 1;
			}
		}
	}
	
	
	return 0;
}

is_params* getFuncParams(char* str){
	table_element* tab;
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL){
			
			if(strcmp(str,tab->fd->id)==0){
				
				return tab->fd->params;
			}
		}
	}
	return NULL;
}

char* getVarType(char* str, is_funcdec* fd,int linha){
	//procurar o type da varaivel str na parte global e na fd
	char *fName = fd->id;
	char *auxType=NULL;
	//procurar na global e na func
	table_element* tab;	
	for(tab=symtab; tab; tab=tab->next){
		if(tab->v!=NULL){
			is_vardecidtab* aux;
			for(aux=tab->v->varspec_list; aux; aux=aux->next){
				if(strcmp(str,aux->id)==0){auxType=tab->v->type;}
			}
		}
		else if(strcmp(fName,tab->fd->id)==0){
			is_listvardec* vars;
			for(vars=tab->fd->lista_var; vars; vars=vars->next){
				is_vardecidtab* v;
				for(v=vars->var->varspec_list; v; v=v->next){
					if(strcmp(str,v->id)==0){
						if(linha > v->linha){
										
						return vars->var->type;}
					}
				}
			}
		}
	}
	//procurar no params da func
	is_params* p;
	for(p=fd->params;p;p=p->next){
		if(strcmp(str,p->id)==0){return p->type;}
	}
	return auxType;
	
}

char* getFuncType(char* str){
	table_element* tab;	
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL && strcmp(str,tab->fd->id)==0){return tab->fd->type;}
	}
	return NULL;
}
int search_var(char* str,char* fName){
	//printf("search var: %s\n",str);
	if(fName==NULL){
		//printf("search var global: %s\n",str);
		//procurar no na global
		table_element* tab;	
		for(tab=symtab; tab; tab=tab->next){
			if(tab->v!=NULL){
				is_vardecidtab* aux;
				for(aux=tab->v->varspec_list; aux; aux=aux->next){
					//printf("%s %s, %d\n",str,aux->id,strcmp(str,aux->id)); debug
					if(strcmp(str,aux->id)==0){return 1;}
				}
			}
		}
	}
	else{
	//procurar na global e na func
		//printf("search var global/func: %s\n",str);
		table_element* tab;	
		for(tab=symtab; tab; tab=tab->next){
			if(tab->fd!=NULL && strcmp(fName,tab->fd->id)==0){
				is_listvardec* vars;
				for(vars=tab->fd->lista_var; vars; vars=vars->next){
					is_vardecidtab* v;
					for(v=vars->var->varspec_list; v; v=v->next){
						if(strcmp(str,v->id)==0){return 1;}
					}
				}
				is_params* p;
				for(p=tab->fd->params;p;p=p->next){
					if(strcmp(str,p->id)==0){return 1;}
				}
			}
			if(tab->v!=NULL){
				is_vardecidtab* aux;
				for(aux=tab->v->varspec_list; aux; aux=aux->next){
					//printf("%s %s, %d\n",str,aux->id,strcmp(str,aux->id)); debug
					if(strcmp(str,aux->id)==0){return 1;}
				}
			}
		}
		
		
	}
	return 0;
}


int search_varInsert(char* str,char* fName){
	//printf("search var: %s\n",str);
	if(fName==NULL){
		//printf("search var global: %s\n",str);
		//procurar no na global
		table_element* tab;	
		for(tab=symtab; tab; tab=tab->next){
			if(tab->v!=NULL){
				is_vardecidtab* aux;
				for(aux=tab->v->varspec_list; aux; aux=aux->next){
					//printf("%s %s, %d\n",str,aux->id,strcmp(str,aux->id)); debug
					if(strcmp(str,aux->id)==0){return 1;}
				}
			}
			if(tab->fd!=NULL){
				if(strcmp(str,tab->fd->id)==0){return 1;}
			}
		}
	}
	else{
	//procurar na global e na func
		//printf("search var global/func: %s\n",str);
		table_element* tab;	
		for(tab=symtab; tab; tab=tab->next){
			if(tab->fd!=NULL && strcmp(fName,tab->fd->id)==0){
				is_listvardec* vars;
				for(vars=tab->fd->lista_var; vars; vars=vars->next){
					is_vardecidtab* v;
					for(v=vars->var->varspec_list; v; v=v->next){
						if(strcmp(str,v->id)==0){return 1;}
					}
				}
				is_params* p;
				for(p=tab->fd->params;p;p=p->next){
					//printf("%s , %s\n",str,p->id);
					if(strcmp(str,p->id)==0){return 1;}
				}
			}
		}
		
		
	}
	return 0;
}

char* toLow(char* str){
	if(str==NULL){return "null";}
	if(strcmp(str,"Int")==0){return "int";}
	if(strcmp(str,"Float32")==0){return "float32";}
	if(strcmp(str,"Bool")==0){return "bool";}
	if(strcmp(str,"String")==0){return "string";}	
	return str;	
}

void show_symtab(){
	
	
	table_element* tab;
	if(symtab==NULL) return;
	printf("===== Global Symbol Table =====\n");
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL) {
			printf("%s\t(",tab->fd->id);
			is_params* p;
			for(p=tab->fd->params; p; p=p->next){
				if(p->next==NULL){printf("%s",toLow(p->type));}
				else{printf("%s,",toLow(p->type));}			
			}
			if(tab->fd->type==NULL){
				printf(")\tnone\n");			
			}
			else{	printf(")\t%s\n",toLow(tab->fd->type)); }			
		}
		else{
			char *vartype=(char*)strdup(tab->v->type);
			is_vardecidtab* var;			
			for(var=tab->v->varspec_list; var; var=var->next){
				printf("%s\t\t%s\n",var->id, toLow(vartype));
			}
		}
	}
	printf("\n");
	for(tab=symtab; tab; tab=tab->next){
		if(tab->fd!=NULL) {
			is_params* aux;
			printf("===== Function %s(",tab->fd->id);
			for(aux=tab->fd->params; aux; aux=aux->next){
				if(aux->next==NULL){printf("%s",toLow(aux->type));}
				else{printf("%s,",toLow(aux->type));}	
			}	
			printf(") Symbol Table =====\n");
			if(tab->fd->type==NULL){
				printf("return\t\tnone\n");			
			}else{
				printf("return\t\t%s\n",toLow(tab->fd->type));
			}
			//params
			
			for(aux=tab->fd->params; aux; aux=aux->next){
				printf("%s\t\t%s\tparam\n",aux->id,toLow(aux->type));
			}
			is_listvardec* vars;
			for(vars=tab->fd->lista_var; vars; vars=vars->next){
				is_vardecidtab* v;
				for(v=vars->var->varspec_list; v; v=v->next){
					printf("%s\t\t%s\n",v->id,toLow(vars->var->type));
				}
			}
			printf("\n");
		}
	}
}



























