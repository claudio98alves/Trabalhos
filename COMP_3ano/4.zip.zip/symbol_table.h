#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H
#include "structures.h"
typedef enum {integer, character, doub} basic_type;


typedef struct _funcEl { /*insere feito*/
	struct _params* params;
	char *type;
	char *id;
	int linha;
	struct _listvardec* lista_var;
} is_funcEl;

typedef struct _vardecidtab {
	char* id;
	int linha;
	int coluna;
	int utilizado;
	struct _vardecidtab* next;	
} is_vardecidtab;

typedef struct _listvardec{
	/*type?*/
	struct _vardectab* var;
	struct _listvardec* next;
}is_listvardec;


typedef struct _vardectab{
	char* type;
	struct _vardecidtab* varspec_list;
}is_vardectab;

typedef struct _t1{
	struct _vardectab* v;
	struct _funcEl* fd;
	struct _t1 *next;
} table_element;

int insert_var(is_vardec* var);
table_element * insert_func(is_funcdec* fd);

int search_var(char* str,char* fName);
int insert_varInFunc(table_element* symbol,is_vardec* var);
void show_symtab();
char* getVarType(char* str, is_funcdec* fd, int linha);
char* getFuncType(char* str);
char* toLow(char* str);
is_params* getFuncParams(char* str);
int checkVars();
void markId(char* str, is_funcdec* fd,int linha);
int search_varInsert(char* str,char* fName);
int check_ffinvoc(char* str);
int check_search_func(is_funcdec* func);
#endif
