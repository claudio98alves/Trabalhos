package ejb;


import data.Customer;
import data.Item;
import org.hibernate.exception.ConstraintViolationException;
import org.mindrot.jbcrypt.BCrypt;

import javax.ejb.Stateful;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Stateless
public class CustomerEJB implements CustomerEJBRemote {
    @PersistenceContext(name = "customers")
    EntityManager em;

    public CustomerEJB() {
    }


    public List<Customer> findCustomerByName(String threshold) {
        System.out.println("Treshhold??? " + threshold);
        Query q = em.createQuery("from Customer p where p.email = :name");
        q.setParameter("name", threshold);
        @SuppressWarnings("unchecked")
        List<Customer> result = q.getResultList();
        return result;
    }

    public String addItem(String name, String category, String origin, String photo, String price, String user){
        Query q = em.createQuery("from Customer p where p.email = :emailId");
        q.setParameter("emailId", user);
        List<Customer> result = q.getResultList();
        Calendar d = Calendar.getInstance();

        //como na base de dados está garantido que so existe um utilizador por email
        Item i = new Item(name,category,origin,photo, d.getTime(),Float.valueOf(price),result.get(0));
        em.persist(i);;
        return "true";
    }


    public String register(String password, String email, String country){
        System.out.println(password);
        Customer c = new Customer(BCrypt.hashpw(password, BCrypt.gensalt()), email, country);


        Query q = em.createQuery("from Customer p where p.email = :emailId");
        q.setParameter("emailId", email);
        List<Customer> result = q.getResultList();
        if(result.size()==0){
            //posso adicionar
            try {
                em.persist(c);
            }catch (ConstraintViolationException e){
                return "Error: Email already registered";
            }
            return "true";
        }
        else{
            return "Error: Email already registered";
        }
    }


    public String login(String email, String password){
        Query q = em.createQuery("from Customer p where p.email = :emailId");
        q.setParameter("emailId",email);
        List<Customer> result = q.getResultList();
        if(result.size()==1 && BCrypt.checkpw(password, result.get(0).getPassword())){
            return "true";
        }
        else{
            if(result.size()==1){

                return "Error: Wrong Password";
            }else{
                return "Error: Email doesnt't belong to any account";
            }
        }
    }

    public List<Item> searchAll(String name){
        Query q = em.createQuery("select item from Item item where item.name like :sug ");
        q.setParameter("sug","%"+name+"%");

        List<Item> result = q.getResultList();
        //parse to string
        return result;
    }

    public List<Item> searchCategory(String name, String category_value){
        System.out.println(name);
        System.out.println(category_value);
        Query q = em.createQuery("select item from Item item where item.category =:val and item.name like :sug ");
        q.setParameter("sug","%"+name+"%");
        q.setParameter("val",category_value);
        List<Item> result = q.getResultList();

        return result;
    }

    public List<Item> searchCountry(String name, String country_value){
        Query q = em.createQuery("select item from Item item where item.origin =:val and item.name like :sug ");
        q.setParameter("sug","%"+name+"%");
        q.setParameter("val",country_value);
        List<Item> result = q.getResultList();
        return result;
    }

    public List<Item> searchPriceRange(String name, String priceRange_value){
        Query q = em.createQuery("select item from Item item where item.price >:valmin and item.price <:valmax and item.name like :sug ");
        q.setParameter("sug","%"+name+"%");
        System.out.println(priceRange_value.split("-")[0].trim());
        System.out.println(priceRange_value.split("-")[1].trim());
        q.setParameter("valmin",Float.parseFloat(priceRange_value.split("-")[0].trim()));
        q.setParameter("valmax",Float.parseFloat(priceRange_value.split("-")[1].trim()));
        List<Item> result = q.getResultList();
        return result;
    }

    public Item getItemById(String id){
        Query q = em.createQuery("select item from Item item where item.id =:id_item");
        q.setParameter("id_item",Long.parseLong(id));
        Item result = (Item) q.getSingleResult();
        return result;
    }

    public String editUser(String realEmail,String email, String password, String country){
        Query q = em.createQuery("select c from Customer c where c.email =:realEmail");
        q.setParameter("realEmail",realEmail);
        Customer result = (Customer) q.getSingleResult();
        String s="";
        System.out.println(email);
        System.out.println(password);
        System.out.println(country);
        if(email!=null && email.compareTo("")!=0){
            result.setEmail(email);
            s = "logout";
        }
        if(password!=null && password.compareTo("")!=0){
            result.setPassword(password);
            s = "logout";
        }
        if(country!=null && country.compareTo("")!=0){
            result.setCountry(country);
        }
        return s;
    }

    public void deleteUser(String email){
        Query q = em.createQuery("from Customer p where p.email = :emailId");
        q.setParameter("emailId",email);
        Customer c = (Customer) q.getSingleResult();

        q = em.createQuery("select item from Item item where customer =:customer");
        q.setParameter("customer",c);
        List<Item> list = q.getResultList();

        for(int i=0; i < list.size();i++){
            deleteItem(list.get(i).getId()+"");
        }
        /*delete user items first*/
        Query q2= em.createQuery("delete from Customer where email =:realEmail");
        q2.setParameter("realEmail",email);
        q2.executeUpdate();
    }

    public List<Item> searchMyItems(String email){
        Query q = em.createQuery("select item from Item item where item.customer.email = :email ");
        q.setParameter("email",email);
        List<Item> result = q.getResultList();
        //parse to string
        return result;
    }

    public List<Item> searchDate(String name, Date date){
        Query q = em.createQuery("select item from Item item where item.data >:data and item.name like :sug  ");
        q.setParameter("data",date);
        q.setParameter("sug","%"+name+"%");
        List<Item> result = q.getResultList();
        System.out.println("searchData");
        //parse to string
        return result;
    }

    public void editItem(String id, String name,String category, String origin, String photo, String price){
        Item i = getItemById(id);
        if(name.compareTo("")!=0)i.setName(name);
        if(category.compareTo("")!=0)i.setCategory(category);
        if(origin.compareTo("")!=0)i.setOrigin(origin);
        if(photo.compareTo("")!=0)i.setPhoto(photo);
        if(price.compareTo("")!=0)i.setPrice(Float.parseFloat(price));
    }

    public void deleteItem(String id){
        Query q = em.createQuery("delete from Item where id =:id");
        q.setParameter("id",Long.parseLong(id));
        q.executeUpdate();
    }
}
