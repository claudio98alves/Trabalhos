package ejb;


import data.Customer;
import data.Item;

import javax.ejb.Remote;
import java.util.Date;
import java.util.List;

@Remote
public interface CustomerEJBRemote {

    List<Customer> findCustomerByName(String threshold);
    String register(String password, String email, String country);
    String login(String email, String password);
    String addItem(String name, String category, String origin, String photo, String price, String user);
    List<Item> searchAll(String name);
    List<Item> searchCountry(String name, String country_value);
    List<Item> searchCategory(String name, String category_value);
    List<Item> searchPriceRange(String name, String priceRange_value);
    Item getItemById(String id);
    String editUser(String realEmail,String email, String password, String country);
    void deleteUser(String email);
    List<Item> searchMyItems(String email);
    void editItem(String id, String name,String category, String origin, String photo, String price);
    void deleteItem(String id);
    List<Item> searchDate(String name,Date date);
}

/*
*  remove origin and put the item associated to the user countries
*  try do fix date to get hours minutes and seconds --> TimeStamp instead of Date
*
*
* */