package data;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
public class Item implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id @GeneratedValue(strategy= GenerationType.AUTO)
    private Long id;
    private String name;
    private String category;
    private String origin;
    private String photo;
    @Temporal(TemporalType.TIMESTAMP)
    private Date data;
    private float price;
    @ManyToOne
    private Customer customer;

    //to teste
    public Item(String name) {
        this.name = name;
    }

    public Item(String name, String category, String origin, String photo, Date data, float price, Customer customer) {
        this.name = name;
        this.category = category;
        this.origin = origin;
        this.photo = photo;
        this.data = data;
        this.price = price;
        this.customer = customer;
    }

    public Item() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }
}
