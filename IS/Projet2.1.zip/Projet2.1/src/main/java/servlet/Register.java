package servlet;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import ejb.CustomerEJBRemote;
import org.jboss.logging.Logger;


@WebServlet("/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    CustomerEJBRemote ejb;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Logger.getLogger(this.getClass()).info("Entering Register page");
        request.setAttribute("msg","");
        RequestDispatcher view=request.getRequestDispatcher("WEB-INF/register.jsp");
        view.forward(request,response);

    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //check email and password then fowartd to HomePage or to error page

        String email = request.getParameter("emailId");
        String password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        String country = request.getParameter("country");
        System.out.println(email);
        System.out.println(password);
        if(email.compareTo("")==0 || password.compareTo("")==0 || password2.compareTo("")==0 || country.compareTo("")==0){
            request.setAttribute("msg","Please fill all fields");
            RequestDispatcher view=request.getRequestDispatcher("WEB-INF/register.jsp");
            view.forward(request,response);
        }
        else if(password.compareTo(password2)!=0){
            System.out.println("passwords doesn't match");
            request.setAttribute("msg","passwords doesn't match");
            RequestDispatcher view=request.getRequestDispatcher("WEB-INF/register.jsp");
            view.forward(request,response);
        }
        else{
            //checkar com a database e verificar se é possivel realizar o register
            String result = ejb.register(password,email,country);
            if(result.compareTo("true")==0){
                request.setAttribute("msg","Register Sucessfull");
                RequestDispatcher view=request.getRequestDispatcher("WEB-INF/home.jsp");
                view.forward(request,response);
            }
            else{
                System.out.println(result);
                request.setAttribute("msg",result.split(":")[1].trim());
                RequestDispatcher view=request.getRequestDispatcher("WEB-INF/register.jsp");
                view.forward(request,response);

            }
        }
    }

}
