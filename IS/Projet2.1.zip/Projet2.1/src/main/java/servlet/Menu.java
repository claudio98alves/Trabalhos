package servlet;

import data.Customer;
import ejb.CustomerEJBRemote;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet("/Menu")
public class Menu extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    CustomerEJBRemote ejb;

    public Menu() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);


        if (session == null || session.getAttribute("emailId") == null ){

            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }else{
            request.setAttribute("msg", "Welcome "+ session.getAttribute("emailId"));
            RequestDispatcher view=request.getRequestDispatcher("WEB-INF/menu.jsp");
            view.forward(request,response);
        }
    }

}
