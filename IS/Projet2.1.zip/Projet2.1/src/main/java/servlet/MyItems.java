package servlet;

import data.Item;
import ejb.CustomerEJBRemote;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/MyItems")
public class MyItems extends HttpServlet {
    private static final long serialVersionUID = 1L;


    @EJB
    CustomerEJBRemote ejb;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("emailId")== null){
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }
        else {

            List<Item> result;
            result = ejb.searchMyItems(session.getAttribute("emailId").toString());
            request.setAttribute("items", result);
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/myItems.jsp");
            view.forward(request, response);
        }
    }
}