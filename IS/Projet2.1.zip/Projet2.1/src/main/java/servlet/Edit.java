package servlet;

import ejb.CustomerEJBRemote;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/Edit")
public class Edit extends HttpServlet {
    private static final long serialVersionUID = 1L;


    @EJB
    CustomerEJBRemote ejb;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("emailId")== null){
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }
        else {
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/edit.jsp");
            view.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //check email and password then fowartd to HomePage or to error page
        HttpSession session = request.getSession(false);

        String email = request.getParameter("emailId");
        String password = request.getParameter("password");
        String password2 = request.getParameter("password2");
        String country = request.getParameter("country");

        if (session == null || session.getAttribute("emailId")== null) {
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }else {
            String result = "";
            //checkar se as pass sao iguais
            result = ejb.editUser(session.getAttribute("emailId").toString(), email, password, country);
            if(result.compareTo("logout")==0){
                //logout
                if(session!=null)
                    session.invalidate();
                request.setAttribute("msg","Logout Succesfull");
                //falta redireionar para o home page
                response.sendRedirect("");

            }else{
                //back
                response.sendRedirect("Menu");
            }

        }
    }


}