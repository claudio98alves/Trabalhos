package servlet;

import data.Item;
import ejb.CustomerEJBRemote;
import org.jboss.logging.Logger;

import javax.ejb.EJB;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@WebServlet("/Search")
public class Search extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    CustomerEJBRemote ejb;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);

        //System.out.println(session.isNew());
        if (session == null || session.getAttribute("emailId")== null){
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }
        else {
            String option = request.getParameter("option");
            if (option == null) {
                //protect the null
                RequestDispatcher view = request.getRequestDispatcher("WEB-INF/search.jsp");
                view.forward(request, response);
            }
            else{
                RequestDispatcher view;
                List<Item> result;
                switch (option){
                    case "all":
                        result = ejb.searchAll(request.getParameter("name"));
                        request.setAttribute("items", result);
                        view = request.getRequestDispatcher("WEB-INF/info.jsp");
                        view.forward(request, response);
                        break;
                    case "category":
                        result = ejb.searchCategory(request.getParameter("name"),request.getParameter("category_value"));
                        request.setAttribute("items", result);
                        view = request.getRequestDispatcher("WEB-INF/info.jsp");
                        view.forward(request, response);
                        break;
                    case "country":
                        result = ejb.searchCountry(request.getParameter("name"),request.getParameter("country_value"));
                        request.setAttribute("items", result);
                        view = request.getRequestDispatcher("WEB-INF/info.jsp");
                        view.forward(request, response);
                        break;
                    case "priceRange":
                        //check priceRange value
                        if(checkPriceRange(request.getParameter("priceRange_value"))) {
                            result = ejb.searchPriceRange(request.getParameter("name"), request.getParameter("priceRange_value"));
                            request.setAttribute("items", result);
                            view = request.getRequestDispatcher("WEB-INF/info.jsp");
                            view.forward(request, response);
                        }else{
                            //here
                            request.setAttribute("msg","Wrong format for price range");
                            view = request.getRequestDispatcher("WEB-INF/search.jsp");
                            view.forward(request, response);
                        }
                        break;
                    case "date":
                        SimpleDateFormat in = new SimpleDateFormat("dd/MM/yyyy");
                        String parameter = request.getParameter("date_value");
                        try {
                            Date date = in.parse(parameter);
                            result = ejb.searchDate(request.getParameter("name"), date);
                            request.setAttribute("items", result);
                            view = request.getRequestDispatcher("WEB-INF/info.jsp");
                            view.forward(request, response);
                        } catch (ParseException e) {
                            //give wrong date format error

                        }
                        break;
                    default:
                        //protect the null
                        view = request.getRequestDispatcher("WEB-INF/search.jsp");
                        view.forward(request, response);

                }
            }


        }
    }
    protected boolean checkPriceRange(String price){
        if(price != null){
            String[] s = price.split("-");
            if(s.length == 2){
                try{
                    float min = Float.parseFloat(s[0]);
                    float max = Float.parseFloat(s[1]);
                    if(min<=max){
                        return true;
                    }
                }catch (Exception e){
                    return false;
                }
            }
        }
        return false;
    }


}
