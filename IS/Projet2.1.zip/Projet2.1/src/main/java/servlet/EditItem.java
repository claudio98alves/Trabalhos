package servlet;


import data.Item;
import ejb.CustomerEJBRemote;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/EditItem")
public class EditItem extends HttpServlet {
    private static final long serialVersionUID = 1L;


    @EJB
    CustomerEJBRemote ejb;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("emailId")== null){
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }
        else {
            request.setAttribute("msg","");
            request.setAttribute("item",ejb.getItemById(request.getParameter("id")));
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/editItem.jsp");
            view.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        String origin = request.getParameter("origin");
        String photo = request.getParameter("photo");
        String price = request.getParameter("price");


        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("emailId")== null){
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }
        else {
            //edit item
            try {
                System.out.println(price);
                if(price !=null && price.compareTo("")!=0){Float.parseFloat(price);}

                ejb.editItem(id,name,category,origin,photo,price);
                response.sendRedirect("MyItems");
            }catch (Exception e){
                request.setAttribute("item",ejb.getItemById(request.getParameter("id")));
                request.setAttribute("msg","Invalid Price");
                RequestDispatcher view = request.getRequestDispatcher("WEB-INF/editItem.jsp");
                view.forward(request, response);
            }

        }
    }
}
