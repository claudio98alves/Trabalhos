package servlet;

import ejb.CustomerEJBRemote;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@WebServlet("/AddItem")
public class AddItem extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @EJB
    CustomerEJBRemote ejb;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("emailId")== null){
            request.setAttribute("msg","Please login first");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/home.jsp");
            view.forward(request, response);
        }
        else {
            request.setAttribute("msg","Please fill all fields");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/addItem.jsp");
            view.forward(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        String origin = request.getParameter("origin");
        String photo = request.getParameter("photo");
        String price = request.getParameter("price");
        HttpSession session = request.getSession(false);
        System.out.println(photo);

        if(name.compareTo("")==0 || category.compareTo("")==0 || origin.compareTo("")==0 || photo.compareTo("")==0 || price.compareTo("")==0){
            request.setAttribute("msg","Please fill all fields");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/addItem.jsp");
            view.forward(request, response);
        }
        else if(!checkPrice(price)){
            request.setAttribute("msg","Inavlid price! Example 1.00");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/addItem.jsp");
            view.forward(request, response);
        }
        else{
            ejb.addItem(name,category,origin,photo,price,session.getAttribute("emailId").toString());
            request.setAttribute("msg","Item added with success");
            RequestDispatcher view = request.getRequestDispatcher("WEB-INF/addItem.jsp");
            view.forward(request, response);
        }



    }



    public boolean checkPrice(String price){
        try{
            Float.parseFloat(price);
            return true;
        }catch (Exception e){
            return false;
        }
    }
}
